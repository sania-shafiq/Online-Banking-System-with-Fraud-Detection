# Banking Project — Local Preview Guide

This README explains how to run the banking project locally for preview (Windows + XAMPP or PHP built-in server).

Prerequisites
- PHP 7.4+ (installed with XAMPP or standalone)
- MySQL / MariaDB (XAMPP includes it)
- phpMyAdmin (optional, included with XAMPP)

1) Place the project in your web root
- Using XAMPP: put the project at `C:\xampp\htdocs\banking-project`

2) Import the database
- Option A (phpMyAdmin):
  - Open `http://localhost/phpmyadmin` and create a new database named `banking_db` (or import directly).
  - Import `database.sql` (file is in the project root).

- Option B (MySQL CLI):
  - Open PowerShell or CMD and run (adjust path if needed):

  ```powershell
  mysql -u root -p < "C:\xampp\htdocs\banking-project\database.sql"
  ```

3) Start servers
- Using XAMPP: start **Apache** and **MySQL** from the XAMPP Control Panel.
- Using PHP built-in server (quick demo): open PowerShell in project folder and run:

  ```powershell
  cd C:\xampp\htdocs\banking-project
  php -S localhost:8000
  ```

4) Open the app
- XAMPP: http://localhost/banking-project/
- Built-in server: http://localhost:8000/

5) Test utilities and demo credentials
- DB check: open `check_db.php` (example: http://localhost/banking-project/check_db.php)
- Demo login: Email `test@example.com`, Password `password` (seeded in `database.sql`).

Notes & Security
- This project is for local preview and development only. Do not run this as-is in production.
- Remove or disable verbose error display (see `db.php`) and tighten DB credentials before deploying.
- Use strong passwords and TLS in production.

If you want, I can:
- Import `database.sql` automatically (requires MySQL credentials).
- Start a PHP built-in server for you and run a quick smoke test.
