<?php
session_start();
include 'db.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$message = '';
$success = false;

// Process registration
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $full_name = $conn->real_escape_string($_POST['full_name']);
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    
    // Validation
    if(empty($full_name) || empty($email) || empty($password)) {
        $message = "Please fill in all required fields!";
    } elseif($password !== $confirm_password) {
        $message = "Passwords do not match!";
    } elseif(strlen($password) < 6) {
        $message = "Password must be at least 6 characters long!";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Please enter a valid email address!";
    } else {
        // Register user
        $result = registerUser($conn, $full_name, $email, $password, $phone, $address);
        
        if($result === "success") {
            $message = "Registration successful! Please login with your credentials.";
            $success = true;
            
            // Clear form fields
            $full_name = $email = $phone = $address = '';
        } else {
            $message = $result;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Register</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .register-container {
            width: 100%;
            max-width: 500px;
            animation: fadeIn 0.8s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Logo Header */
        .logo-header {
            text-align: center;
            margin-bottom: 30px;
            color: white;
        }
        
        .logo-header i {
            font-size: 3.5rem;
            margin-bottom: 15px;
            display: block;
        }
        
        .logo-header h1 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .logo-header p {
            opacity: 0.9;
            font-size: 1rem;
        }
        
        /* Register Card */
        .register-card {
            background-color: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
            max-height: 90vh;
            overflow-y: auto;
        }
        
        /* Hide scrollbar but keep functionality */
        .register-card::-webkit-scrollbar {
            width: 5px;
        }
        
        .register-card::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        .register-card::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        
        .register-card::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .card-header h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
            margin-bottom: 10px;
        }
        
        .card-header p {
            color: #666;
            font-size: 0.95rem;
        }
        
        /* Message Box */
        .message-box {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease-out;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Form Grid */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }
        
        @media (max-width: 576px) {
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group label .required {
            color: #dc3545;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            font-size: 1.1rem;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #1a3a8f;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 58, 143, 0.1);
        }
        
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 1.1rem;
        }
        
        /* Password Strength */
        .password-strength {
            margin-top: 10px;
            height: 5px;
            border-radius: 5px;
            background-color: #e0e0e0;
            overflow: hidden;
        }
        
        .strength-bar {
            height: 100%;
            width: 0%;
            transition: width 0.3s, background-color 0.3s;
        }
        
        .strength-weak {
            background-color: #dc3545;
            width: 33%;
        }
        
        .strength-medium {
            background-color: #ffc107;
            width: 66%;
        }
        
        .strength-strong {
            background-color: #28a745;
            width: 100%;
        }
        
        .strength-text {
            font-size: 0.85rem;
            color: #666;
            margin-top: 5px;
            display: flex;
            justify-content: space-between;
        }
        
        /* Terms and Conditions */
        .terms-group {
            display: flex;
            align-items: flex-start;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .terms-group input[type="checkbox"] {
            margin-top: 3px;
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .terms-group label {
            color: #666;
            font-size: 0.95rem;
            line-height: 1.5;
            cursor: pointer;
        }
        
        .terms-group a {
            color: #1a3a8f;
            text-decoration: none;
            font-weight: 600;
        }
        
        .terms-group a:hover {
            text-decoration: underline;
        }
        
        /* Submit Button */
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(to right, #1a3a8f, #2c5cc5);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(26, 58, 143, 0.2);
        }
        
        .submit-btn:disabled {
            background: #cccccc;
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        
        .submit-btn:active {
            transform: translateY(0);
        }
        
        /* Login Link */
        .login-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e0e0e0;
        }
        
        .login-link p {
            color: #666;
            margin-bottom: 10px;
        }
        
        .login-btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: #f8f9fa;
            color: #1a3a8f;
            border: 2px solid #1a3a8f;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .login-btn:hover {
            background-color: #1a3a8f;
            color: white;
        }
        
        /* Benefits List */
        .benefits-list {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 25px;
            border-left: 4px solid #28a745;
        }
        
        .benefits-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            color: #155724;
        }
        
        .benefits-header i {
            font-size: 1.2rem;
        }
        
        .benefits-list ul {
            padding-left: 20px;
            color: #666;
        }
        
        .benefits-list li {
            margin-bottom: 8px;
            font-size: 0.9rem;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .register-card {
                padding: 30px 25px;
            }
            
            .logo-header h1 {
                font-size: 1.8rem;
            }
            
            .card-header h2 {
                font-size: 1.5rem;
            }
        }
        
        @media (max-width: 400px) {
            .logo-header i {
                font-size: 2.8rem;
            }
            
            .logo-header h1 {
                font-size: 1.6rem;
            }
            
            .register-card {
                padding: 25px 20px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="register-container">
        <!-- Logo Header -->
        <div class="logo-header">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
            <p>Join thousands of satisfied customers</p>
        </div>
        
        <!-- Register Card -->
        <div class="register-card">
            <!-- Card Header -->
            <div class="card-header">
                <h2>Create Account</h2>
                <p>Fill in your details to get started</p>
            </div>
            
            <!-- Message Box -->
            <?php if($message): ?>
            <div class="message-box <?php echo $success ? 'success' : 'error'; ?>">
                <i class="fas <?php echo $success ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <?php echo htmlspecialchars($message); ?>
                <?php if($success): ?>
                <script>
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 3000);
                </script>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            
            <!-- Registration Form -->
            <form method="POST" action="" id="registerForm">
                <div class="form-grid">
                    <!-- Full Name -->
                    <div class="form-group">
                        <label for="full_name">Full Name <span class="required">*</span></label>
                        <div class="input-group">
                            <i class="fas fa-user"></i>
                            <input type="text" name="full_name" id="full_name" class="form-control" 
                                   placeholder="Enter your full name" required
                                   value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>">
                        </div>
                    </div>
                    
                    <!-- Email -->
                    <div class="form-group">
                        <label for="email">Email Address <span class="required">*</span></label>
                        <div class="input-group">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="email" id="email" class="form-control" 
                                   placeholder="Enter your email" required
                                   value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                        </div>
                    </div>
                    
                    <!-- Phone -->
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <div class="input-group">
                            <i class="fas fa-phone"></i>
                            <input type="tel" name="phone" id="phone" class="form-control" 
                                   placeholder="Enter your phone number"
                                   value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
                        </div>
                    </div>
                    
                    <!-- Password -->
                    <div class="form-group">
                        <label for="password">Password <span class="required">*</span></label>
                        <div class="input-group">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="password" class="form-control" 
                                   placeholder="Create a password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword('password')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div class="password-strength">
                            <div class="strength-bar" id="passwordStrength"></div>
                        </div>
                        <div class="strength-text">
                            <span>Password strength:</span>
                            <span id="strengthText">None</span>
                        </div>
                    </div>
                    
                    <!-- Confirm Password -->
                    <div class="form-group">
                        <label for="confirm_password">Confirm Password <span class="required">*</span></label>
                        <div class="input-group">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="confirm_password" id="confirm_password" class="form-control" 
                                   placeholder="Confirm your password" required>
                            <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                <i class="fas fa-eye"></i>
                            </button>
                        </div>
                        <div id="passwordMatch" style="font-size: 0.85rem; margin-top: 5px;"></div>
                    </div>
                    
                    <!-- Address -->
                    <div class="form-group full-width">
                        <label for="address">Address</label>
                        <textarea name="address" id="address" class="form-control" 
                                  placeholder="Enter your complete address" 
                                  rows="3"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                    </div>
                </div>
                
                <!-- Terms and Conditions -->
                <div class="terms-group">
                    <input type="checkbox" id="terms" name="terms" required>
                    <label for="terms">
                        I agree to the <a href="#" onclick="showTerms()">Terms and Conditions</a> and 
                        <a href="#" onclick="showPrivacy()">Privacy Policy</a> <span class="required">*</span>
                    </label>
                </div>
                
                <!-- Submit Button -->
                <button type="submit" name="register" class="submit-btn" id="submitBtn">
                    <i class="fas fa-user-plus"></i>
                    Create Account
                </button>
            </form>
            
            <!-- Benefits List -->
            <div class="benefits-list">
                <div class="benefits-header">
                    <i class="fas fa-star"></i>
                    <h3>Benefits of Joining</h3>
                </div>
                <ul>
                    <li>Free online banking 24/7</li>
                    <li>Zero maintenance fees for premium accounts</li>
                    <li>Instant money transfers</li>
                    <li>Secure and encrypted transactions</li>
                    <li>24/7 customer support</li>
                </ul>
            </div>
            
            <!-- Login Link -->
            <div class="login-link">
                <p>Already have an account?</p>
                <a href="login.php" class="login-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    Sign In Now
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle password visibility
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const toggleBtn = input.parentElement.querySelector('.password-toggle i');
            
            if(input.type === 'password') {
                input.type = 'text';
                toggleBtn.classList.remove('fa-eye');
                toggleBtn.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggleBtn.classList.remove('fa-eye-slash');
                toggleBtn.classList.add('fa-eye');
            }
        }
        
        // Check password strength
        document.getElementById('password').addEventListener('input', function() {
            const password = this.value;
            const strengthBar = document.getElementById('passwordStrength');
            const strengthText = document.getElementById('strengthText');
            
            let strength = 0;
            let text = 'Weak';
            
            // Check password length
            if(password.length >= 6) strength++;
            if(password.length >= 8) strength++;
            
            // Check for uppercase letters
            if(/[A-Z]/.test(password)) strength++;
            
            // Check for numbers
            if(/[0-9]/.test(password)) strength++;
            
            // Check for special characters
            if(/[^A-Za-z0-9]/.test(password)) strength++;
            
            // Update strength bar and text
            if(password.length === 0) {
                strengthBar.className = 'strength-bar';
                strengthBar.style.width = '0%';
                strengthText.textContent = 'None';
            } else if(strength <= 2) {
                strengthBar.className = 'strength-bar strength-weak';
                strengthText.textContent = 'Weak';
            } else if(strength <= 4) {
                strengthBar.className = 'strength-bar strength-medium';
                strengthText.textContent = 'Medium';
            } else {
                strengthBar.className = 'strength-bar strength-strong';
                strengthText.textContent = 'Strong';
            }
            
            checkPasswordMatch();
        });
        
        // Check password match
        function checkPasswordMatch() {
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const matchElement = document.getElementById('passwordMatch');
            
            if(confirmPassword.length === 0) {
                matchElement.textContent = '';
                matchElement.style.color = '';
            } else if(password === confirmPassword) {
                matchElement.textContent = '✓ Passwords match';
                matchElement.style.color = '#28a745';
            } else {
                matchElement.textContent = '✗ Passwords do not match';
                matchElement.style.color = '#dc3545';
            }
        }
        
        document.getElementById('confirm_password').addEventListener('input', checkPasswordMatch);
        
        // Form validation
        document.getElementById('registerForm').addEventListener('submit', function(e) {
            const fullName = document.getElementById('full_name').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            const terms = document.getElementById('terms').checked;
            
            // Name validation
            if(fullName.trim().length < 2) {
                alert('Please enter your full name!');
                e.preventDefault();
                return;
            }
            
            // Email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailRegex.test(email)) {
                alert('Please enter a valid email address!');
                e.preventDefault();
                return;
            }
            
            // Password validation
            if(password.length < 6) {
                alert('Password must be at least 6 characters long!');
                e.preventDefault();
                return;
            }
            
            if(password !== confirmPassword) {
                alert('Passwords do not match!');
                e.preventDefault();
                return;
            }
            
            // Terms validation
            if(!terms) {
                alert('You must agree to the Terms and Conditions!');
                e.preventDefault();
                return;
            }
            
            // Show loading state
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Creating Account...';
            submitBtn.disabled = true;
        });
        
        // Terms and Privacy modals
        function showTerms() {
            alert('TERMS AND CONDITIONS\n\n1. Account Security: You are responsible for maintaining the confidentiality of your account.\n2. Transactions: All transactions are final and cannot be reversed.\n3. Fees: We reserve the right to change fees with prior notice.\n4. Termination: We may terminate accounts that violate our policies.\n\nPlease read the full terms on our website.');
            return false;
        }
        
        function showPrivacy() {
            alert('PRIVACY POLICY\n\n1. Data Collection: We collect necessary information for banking services.\n2. Data Usage: Your data is used only for banking operations.\n3. Data Protection: We use encryption to protect your information.\n4. Third Parties: We do not sell your data to third parties.\n\nYour privacy is important to us.');
            return false;
        }
        
        // Phone number formatting
        document.getElementById('phone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if(value.length > 3 && value.length <= 6) {
                value = value.replace(/(\d{3})(\d+)/, '$1-$2');
            } else if(value.length > 6) {
                value = value.replace(/(\d{3})(\d{3})(\d+)/, '$1-$2-$3');
            }
            e.target.value = value;
        });
        
        // Auto-focus first field
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('full_name').focus();
        });
        
        // Enter key navigation
        document.addEventListener('keydown', function(e) {
            if(e.key === 'Enter' && document.activeElement.tagName !== 'TEXTAREA') {
                e.preventDefault();
                const form = document.getElementById('registerForm');
                const inputs = Array.from(form.querySelectorAll('input, textarea'));
                const currentIndex = inputs.indexOf(document.activeElement);
                
                if(currentIndex < inputs.length - 1) {
                    inputs[currentIndex + 1].focus();
                }
            }
        });
        
        // Real-time email validation
        document.getElementById('email').addEventListener('blur', function() {
            const email = this.value;
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if(email && !emailRegex.test(email)) {
                this.style.borderColor = '#dc3545';
                this.style.backgroundColor = '#f8d7da';
            } else {
                this.style.borderColor = '#e0e0e0';
                this.style.backgroundColor = 'white';
            }
        });
    </script>
</body>
</html>