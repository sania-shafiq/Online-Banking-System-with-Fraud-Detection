<?php
// Enable verbose errors for local debugging (remove in production)
ini_set('display_errors', 1);
error_reporting(E_ALL);
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Check if session is not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database Configuration
$host = "localhost";
$username = "root";
$password = "";
$database = "banking_db";

// Create connection
$conn = new mysqli($host, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to UTF-8
$conn->set_charset("utf8mb4");

// ============================================
// USER AUTHENTICATION FUNCTIONS
// ============================================

/**
 * Check if user is logged in
 * Redirect to login if not
 */
function checkLogin() {
    if(!isset($_SESSION['user_id'])) {
        header("Location: index.php");
        exit();
    }
}

/**
 * Register a new user
 */
function registerUser($conn, $full_name, $email, $password, $phone, $address) {
    // Check if email already exists
    $check_sql = "SELECT id FROM users WHERE email = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if($check_result->num_rows > 0) {
        return "Email already exists!";
    }
    
    // Hash password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    // Generate account number
    $account_number = "ACC" . date('Ymd') . rand(1000, 9999);
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Insert user
        $sql = "INSERT INTO users (full_name, email, password, phone, address) VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssss", $full_name, $email, $hashed_password, $phone, $address);
        $stmt->execute();
        
        // Use connection insert_id (mysqli_stmt does not provide insert_id reliably)
        $user_id = $conn->insert_id;
        
        // Create account for user
        $account_sql = "INSERT INTO accounts (user_id, account_number, balance) VALUES (?, ?, 0.00)";
        $account_stmt = $conn->prepare($account_sql);
        $account_stmt->bind_param("is", $user_id, $account_number);
        $account_stmt->execute();
        
        $conn->commit();
        return "success";
        
    } catch (Exception $e) {
        $conn->rollback();
        return "Registration failed: " . $e->getMessage();
    }
}

/**
 * Login user
 */
function loginUser($conn, $email, $password) {
    $sql = "SELECT id, full_name, password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        
        if(password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            return true;
        }
    }
    
    return false;
}

/**
 * Get user account information
 */
function getUserAccount($conn, $user_id) {
    $sql = "SELECT * FROM accounts WHERE user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        return $result->fetch_assoc();
    }
    
    return null;
}

/**
 * Update account balance
 */
function updateBalance($conn, $account_id, $amount, $type) {
    $operator = ($type == 'Deposit') ? '+' : '-';
    
    $sql = "UPDATE accounts SET balance = balance $operator ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("di", $amount, $account_id);
    return $stmt->execute();
}

/**
 * Get current balance
 */
function getCurrentBalance($conn, $account_id) {
    $sql = "SELECT balance FROM accounts WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $account_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['balance'];
    }
    
    return 0;
}

/**
 * Get recent transactions
 */
function getRecentTransactions($conn, $account_id, $limit = 5) {
    $sql = "SELECT * FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $account_id, $limit);
    $stmt->execute();
    return $stmt->get_result();
}

/**
 * Get total loan amount
 */
function getTotalLoan($conn, $account_id) {
    $sql = "SELECT SUM(amount) as total FROM loans WHERE account_id = ? AND status = 'Approved'";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $account_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    return $row['total'] ?? 0;
}

/**
 * Transfer money between accounts
 */
function transferMoney($conn, $from_account_id, $to_account_number, $amount, $description) {
    // Check if recipient account exists
    $check_sql = "SELECT id, balance FROM accounts WHERE account_number = ?";
    $check_stmt = $conn->prepare($check_sql);
    $check_stmt->bind_param("s", $to_account_number);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if($check_result->num_rows == 0) {
        return "Recipient account not found!";
    }
    
    $recipient = $check_result->fetch_assoc();
    $to_account_id = $recipient['id'];
    
    // Check if sender has sufficient balance
    $sender_balance = getCurrentBalance($conn, $from_account_id);
    if($amount > $sender_balance) {
        return "Insufficient balance!";
    }
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Deduct from sender
        updateBalance($conn, $from_account_id, $amount, 'Withdrawal');
        $sender_new_balance = getCurrentBalance($conn, $from_account_id);
        
        // Add to recipient
        updateBalance($conn, $to_account_id, $amount, 'Deposit');
        $recipient_new_balance = getCurrentBalance($conn, $to_account_id);
        
        // Record sender transaction
        $sender_sql = "INSERT INTO transactions (account_id, type, amount, description, balance_after) VALUES (?, 'Transfer', ?, ?, ?)";
        $sender_stmt = $conn->prepare($sender_sql);
        $desc = "Transfer to " . $to_account_number . " - " . $description;
        $sender_stmt->bind_param("idsd", $from_account_id, $amount, $desc, $sender_new_balance);
        $sender_stmt->execute();
        
        // Record recipient transaction
        $recipient_sql = "INSERT INTO transactions (account_id, type, amount, description, balance_after) VALUES (?, 'Deposit', ?, ?, ?)";
        $recipient_stmt = $conn->prepare($recipient_sql);
        $recipient_desc = "Received from transfer - " . $description;
        $recipient_stmt->bind_param("idsd", $to_account_id, $amount, $recipient_desc, $recipient_new_balance);
        $recipient_stmt->execute();
        
        $conn->commit();
        return "success";
        
    } catch (Exception $e) {
        $conn->rollback();
        return "Transfer failed: " . $e->getMessage();
    }
}
?>