# SecureBank — Code Documentation

## Overview
SecureBank is a small PHP/MySQL web application demonstrating basic online banking features: registration, login, account creation, deposits, withdrawals, transfers, loans, and transactions.

## Project Structure
- `index.php` — Landing page with hero, features, and adaptive navigation (shows Login/Register when logged out; Dashboard/Logout when logged in).
- `login.php` — Login form and processing. Uses `loginUser()` from `db.php`.
- `register.php` — User registration and account creation. Uses `registerUser()` from `db.php`.
- `dashboard.php` — User dashboard (requires login).
- `db.php` — Database connection and core functions (authentication, account management, transactions, transfers, balance updates).
- `account.php`, `deposit.php`, `withdraw.php`, `transfer.php`, `transactions.php`, `loan.php` — Functional pages for banking operations.
- `database.sql` — SQL schema and sample data for creating the `banking_db` database.
- `logout.php` — Destroys session and logs the user out.

## Important Files & Functions
### `db.php`
- Connection configuration: modify `$host`, `$username`, `$password`, `$database` at the top.
- `registerUser($conn, $full_name, $email, $password, $phone, $address)` — Register user, create account row, returns `"success"` or error string.
- `loginUser($conn, $email, $password)` — Verifies credentials and sets `$_SESSION['user_id']` and `$_SESSION['full_name']` on success.
- `checkLogin()` — Helper to redirect to `index.php` if user is not logged in (used by pages requiring auth).
- Account helpers: `getUserAccount()`, `updateBalance()`, `getCurrentBalance()`, `getRecentTransactions()`, `transferMoney()`, `getTotalLoan()`.

## Database
- The app expects a MySQL database named `banking_db` (see `db.php`).
- Import `database.sql` to create required tables (`users`, `accounts`, `transactions`, `loans`, ...).

## Session & Auth Flow
- Sessions are started in `db.php` if not already active.
- After successful login via `login.php`, `$_SESSION['user_id']` is set and used to show dashboard links and protect pages.

## How to Run Locally
1. Start PHP built-in server from the project folder:

```powershell
cd banking-project\banking-project
php -S localhost:8000
```

2. Import `database.sql` into your MySQL server and update DB credentials in `db.php` if needed.
3. Visit `http://localhost:8000`.

## Notes & Security
- Passwords are hashed using `password_hash()` and verified with `password_verify()`.
- Prepared statements are used for queries in `db.php` to reduce SQL injection risk, but ensure all inputs are validated.
- No CSRF protection is implemented — add CSRF tokens for production forms.
- No email verification or secure password reset — these are omitted for demo purposes.

## Where to Update Developer Credit
- Footer credit was added to `index.php`. To change the developer/credit text globally, update the footer section in `index.php` or consider extracting the footer into a separate include (e.g., `includes/footer.php`) and include it in all pages.

## Next Steps / Recommendations
- Add a shared header/footer include to avoid duplication across pages.
- Add CSRF tokens and stronger input validation.
- Add unit or integration tests for critical functions in `db.php`.

---
Generated on: 2025-12-30
Developed by: University of Lahore Developers
