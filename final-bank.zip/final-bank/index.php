<?php
session_start();
include 'db.php';
// NOTE: Removed automatic redirect so index.php remains accessible
// even when a user session is active. Navigation will adapt below.
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Your Trusted Banking Partner</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f8f9fa;
            color: #333;
            line-height: 1.6;
        }
        
        /* Header & Navigation */
        header {
            background: linear-gradient(to right, #1a3a8f, #2c5cc5);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 1000;
        }
        
        .nav-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo i {
            font-size: 2.2rem;
        }
        
        .logo h1 {
            font-size: 1.8rem;
            font-weight: 700;
        }
        
        nav ul {
            display: flex;
            list-style: none;
            gap: 30px;
        }
        
        nav a {
            color: white;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 8px 16px;
            border-radius: 6px;
            transition: all 0.3s;
        }
        
        nav a:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-buttons {
            display: flex;
            gap: 15px;
        }
        
        .btn {
            padding: 10px 25px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-outline {
            background-color: transparent;
            color: white;
            border: 2px solid white;
        }
        
        .btn-outline:hover {
            background-color: white;
            color: #1a3a8f;
        }
        
        .btn-primary {
            background-color: white;
            color: #1a3a8f;
            border: 2px solid white;
        }
        
        .btn-primary:hover {
            background-color: rgba(255, 255, 255, 0.9);
        }
        
        /* Hero Section */
        .hero {
            background: linear-gradient(135deg, rgba(26, 58, 143, 0.9), rgba(44, 92, 197, 0.9)),
                        url('https://images.unsplash.com/photo-1501167786227-4cba60f6d58f?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 100px 20px;
            text-align: center;
        }
        
        .hero-content {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .hero h2 {
            font-size: 3.5rem;
            margin-bottom: 20px;
            font-weight: 700;
            line-height: 1.2;
        }
        
        .hero p {
            font-size: 1.3rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }
        
        .hero-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-top: 40px;
        }
        
        .hero-buttons .btn {
            padding: 15px 35px;
            font-size: 1.1rem;
        }
        
        /* Features Section */
        .features {
            padding: 80px 20px;
            background-color: white;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            color: #1a3a8f;
            margin-bottom: 15px;
        }
        
        .section-title p {
            font-size: 1.2rem;
            color: #666;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .feature-card {
            background-color: #f8f9fa;
            border-radius: 15px;
            padding: 40px 30px;
            text-align: center;
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid #e0e0e0;
        }
        
        .feature-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }
        
        .feature-icon {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 25px;
        }
        
        .feature-icon i {
            font-size: 2.5rem;
            color: white;
        }
        
        .feature-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: #1a3a8f;
        }
        
        .feature-card p {
            color: #666;
            font-size: 1rem;
        }
        
        /* How It Works */
        .how-it-works {
            padding: 80px 20px;
            background-color: #f8f9fa;
        }
        
        .steps {
            display: flex;
            justify-content: center;
            gap: 40px;
            max-width: 1000px;
            margin: 50px auto 0;
            flex-wrap: wrap;
        }
        
        .step {
            flex: 1;
            min-width: 250px;
            text-align: center;
            padding: 30px;
            position: relative;
        }
        
        .step-number {
            width: 60px;
            height: 60px;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.8rem;
            font-weight: 700;
            margin: 0 auto 25px;
        }
        
        .step h3 {
            font-size: 1.3rem;
            margin-bottom: 15px;
            color: #1a3a8f;
        }
        
        .step p {
            color: #666;
        }
        
        /* Testimonials */
        .testimonials {
            padding: 80px 20px;
            background-color: white;
        }
        
        .testimonial-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            max-width: 1200px;
            margin: 50px auto 0;
        }
        
        .testimonial-card {
            background-color: #f8f9fa;
            border-radius: 15px;
            padding: 30px;
            border-left: 4px solid #1a3a8f;
        }
        
        .testimonial-text {
            font-style: italic;
            color: #666;
            margin-bottom: 20px;
            font-size: 1.1rem;
            line-height: 1.6;
        }
        
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .author-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .author-info h4 {
            color: #1a3a8f;
            margin-bottom: 5px;
        }
        
        .author-info p {
            color: #666;
            font-size: 0.9rem;
        }
        
        /* CTA Section */
        .cta {
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            color: white;
            padding: 80px 20px;
            text-align: center;
        }
        
        .cta-content {
            max-width: 800px;
            margin: 0 auto;
        }
        
        .cta h2 {
            font-size: 2.8rem;
            margin-bottom: 20px;
        }
        
        .cta p {
            font-size: 1.2rem;
            margin-bottom: 40px;
            opacity: 0.9;
        }
        
        .cta-buttons {
            display: flex;
            gap: 20px;
            justify-content: center;
        }
        
        .cta-buttons .btn {
            padding: 15px 40px;
            font-size: 1.1rem;
        }
        
        .cta-buttons .btn-outline {
            background-color: transparent;
            color: white;
            border: 2px solid white;
        }
        
        .cta-buttons .btn-outline:hover {
            background-color: white;
            color: #1a3a8f;
        }
        
        /* Footer */
        footer {
            background-color: #1a1a1a;
            color: white;
            padding: 60px 20px 30px;
        }
        
        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
        }
        
        .footer-column h3 {
            color: white;
            margin-bottom: 25px;
            font-size: 1.3rem;
            position: relative;
            padding-bottom: 10px;
        }
        
        .footer-column h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 40px;
            height: 3px;
            background-color: #2c5cc5;
        }
        
        .footer-links {
            list-style: none;
        }
        
        .footer-links li {
            margin-bottom: 12px;
        }
        
        .footer-links a {
            color: #b0b0b0;
            text-decoration: none;
            transition: color 0.3s;
        }
        
        .footer-links a:hover {
            color: white;
        }
        
        .contact-info {
            list-style: none;
        }
        
        .contact-info li {
            margin-bottom: 15px;
            display: flex;
            align-items: flex-start;
            gap: 10px;
            color: #b0b0b0;
        }
        
        .contact-info i {
            color: #2c5cc5;
            font-size: 1.2rem;
            margin-top: 3px;
        }
        
        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .social-links a {
            width: 40px;
            height: 40px;
            background-color: #2c5cc5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .social-links a:hover {
            background-color: white;
            color: #1a3a8f;
            transform: translateY(-3px);
        }
        
        .copyright {
            text-align: center;
            margin-top: 50px;
            padding-top: 30px;
            border-top: 1px solid #333;
            color: #b0b0b0;
            font-size: 0.9rem;
        }
        
        /* Mobile Navigation */
        .mobile-menu-btn {
            display: none;
            background: none;
            border: none;
            color: white;
            font-size: 1.8rem;
            cursor: pointer;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .hero h2 {
                font-size: 2.8rem;
            }
            
            .nav-container {
                flex-wrap: wrap;
            }
            
            nav {
                display: none;
                width: 100%;
                margin-top: 20px;
            }
            
            nav.show {
                display: block;
            }
            
            nav ul {
                flex-direction: column;
                gap: 10px;
            }
            
            .mobile-menu-btn {
                display: block;
            }
            
            .hero-buttons {
                flex-direction: column;
                align-items: center;
            }
            
            .hero-buttons .btn {
                width: 100%;
                max-width: 300px;
            }
        }
        
        @media (max-width: 768px) {
            .hero h2 {
                font-size: 2.2rem;
            }
            
            .hero p {
                font-size: 1.1rem;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
            
            .cta h2 {
                font-size: 2.2rem;
            }
            
            .steps {
                flex-direction: column;
                align-items: center;
            }
        }
        
        @media (max-width: 576px) {
            .nav-buttons {
                flex-direction: column;
                width: 100%;
                margin-top: 15px;
            }
            
            .nav-buttons .btn {
                width: 100%;
                text-align: center;
                justify-content: center;
            }
            
            .cta-buttons {
                flex-direction: column;
            }
            
            .cta-buttons .btn {
                width: 100%;
                max-width: 300px;
                margin: 0 auto;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Header & Navigation -->
    <header>
        <div class="nav-container">
            <div class="logo">
                <i class="fas fa-university"></i>
                <h1>SecureBank</h1>
            </div>
            
            <button class="mobile-menu-btn" id="mobileMenuBtn">
                <i class="fas fa-bars"></i>
            </button>
            
            <nav id="mainNav">
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#how-it-works">How It Works</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
            </nav>
            
            <div class="nav-buttons">
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php" class="btn btn-outline">
                        <i class="fas fa-tachometer-alt"></i> Dashboard
                    </a>
                    <a href="logout.php" class="btn btn-primary">
                        <i class="fas fa-sign-out-alt"></i> Logout
                    </a>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline">
                        <i class="fas fa-sign-in-alt"></i> Login
                    </a>
                    <a href="register.php" class="btn btn-primary">
                        <i class="fas fa-user-plus"></i> Sign Up
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </header>

    <!-- Hidden demo login form (submits to login.php) -->
    <form id="demoLoginForm" method="POST" action="login.php" style="display:none;">
        <input type="hidden" name="email" id="demo_form_email" value="">
        <input type="hidden" name="password" id="demo_form_password" value="">
        <input type="hidden" name="login" value="1">
    </form>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-content">
            <h2>Banking Made Simple, Secure & Smart</h2>
            <p>Experience the future of banking with our secure, fast, and reliable online banking platform. Manage your finances from anywhere, anytime.</p>
            
            <div class="hero-buttons">
                <a href="register.php" class="btn btn-primary">
                    <i class="fas fa-rocket"></i> Get Started Free
                </a>
                <a href="#features" class="btn btn-outline">
                    <i class="fas fa-play-circle"></i> Learn More
                </a>
            </div>
            <!-- Demo quick-login -->
            <div style="margin-top:18px; text-align:center; color: #fff;">
                <div style="display:inline-block; background: rgba(0,0,0,0.15); padding:12px 18px; border-radius:10px;">
                    <strong>Demo account:</strong>
                    <div style="margin-top:6px; font-size:0.95rem;">Email: <span id="demoEmail">test@example.com</span></div>
                    <div style="font-size:0.95rem;">Password: <span id="demoPass">password</span></div>
                    <div style="margin-top:10px;">
                        <button class="btn btn-outline" type="button" onclick="loginDemo()"><i class="fas fa-sign-in-alt"></i> Login as Demo</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features" id="features">
        <div class="section-title">
            <h2>Why Choose SecureBank?</h2>
            <p>We provide cutting-edge banking solutions tailored to meet your financial needs</p>
        </div>
        
        <div class="features-grid">
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h3>Bank-Level Security</h3>
                <p>256-bit encryption and multi-factor authentication to keep your money and data safe</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-bolt"></i>
                </div>
                <h3>Instant Transfers</h3>
                <p>Send and receive money instantly with zero transaction fees for premium accounts</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <h3>Mobile Banking</h3>
                <p>Full banking services available 24/7 on your smartphone or tablet</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <h3>Easy Loans</h3>
                <p>Quick loan approval with competitive interest rates and flexible repayment options</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <h3>Smart Savings</h3>
                <p>Automated savings plans and investment options to grow your wealth</p>
            </div>
            
            <div class="feature-card">
                <div class="feature-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <h3>24/7 Support</h3>
                <p>Round-the-clock customer support via chat, email, and phone</p>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="how-it-works" id="how-it-works">
        <div class="section-title">
            <h2>How It Works</h2>
            <p>Get started with SecureBank in just 3 simple steps</p>
        </div>
        
        <div class="steps">
            <div class="step">
                <div class="step-number">1</div>
                <h3>Create Account</h3>
                <p>Sign up in minutes with your email and basic information</p>
            </div>
            
            <div class="step">
                <div class="step-number">2</div>
                <h3>Verify Identity</h3>
                <p>Quick identity verification to ensure account security</p>
            </div>
            
            <div class="step">
                <div class="step-number">3</div>
                <h3>Start Banking</h3>
                <p>Access all banking features and manage your finances</p>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="testimonials" id="testimonials">
        <div class="section-title">
            <h2>What Our Customers Say</h2>
            <p>Join thousands of satisfied customers who trust SecureBank</p>
        </div>
        
        <div class="testimonial-grid">
            <div class="testimonial-card">
                <div class="testimonial-text">
                    "SecureBank has transformed how I manage my finances. The interface is intuitive and the security features give me peace of mind."
                </div>
                <div class="testimonial-author">
                    <div class="author-avatar">RS</div>
                    <div class="author-info">
                        <h4>Raj Sharma</h4>
                        <p>Business Owner, 3+ years with SecureBank</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <div class="testimonial-text">
                    "The loan process was incredibly smooth. I got approved within hours and the funds were in my account the next day!"
                </div>
                <div class="testimonial-author">
                    <div class="author-avatar">PS</div>
                    <div class="author-info">
                        <h4>Priya Singh</h4>
                        <p>Teacher, 2 years with SecureBank</p>
                    </div>
                </div>
            </div>
            
            <div class="testimonial-card">
                <div class="testimonial-text">
                    "As someone who travels frequently, mobile banking is essential. SecureBank's app is reliable and packed with features."
                </div>
                <div class="testimonial-author">
                    <div class="author-avatar">AK</div>
                    <div class="author-info">
                        <h4>Amit Kumar</h4>
                        <p>Software Engineer, 1 year with SecureBank</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta">
        <div class="cta-content">
            <h2>Ready to Transform Your Banking Experience?</h2>
            <p>Join SecureBank today and take control of your financial future</p>
            
            <div class="cta-buttons">
                <a href="register.php" class="btn btn-primary">
                    <i class="fas fa-user-plus"></i> Sign Up Free
                </a>
                <a href="login.php" class="btn btn-outline">
                    <i class="fas fa-sign-in-alt"></i> Existing User? Login
                </a>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer id="contact">
        <div class="footer-content">
            <div class="footer-column">
                <h3>SecureBank</h3>
                <p style="color: #b0b0b0; margin-bottom: 20px;">Your trusted partner in banking since 2010. Providing secure and innovative financial solutions.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
            
            <div class="footer-column">
                <h3>Quick Links</h3>
                <ul class="footer-links">
                    <li><a href="#home">Home</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#how-it-works">How It Works</a></li>
                    <li><a href="#testimonials">Testimonials</a></li>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php">Register</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3>Services</h3>
                <ul class="footer-links">
                    <li><a href="#">Personal Banking</a></li>
                    <li><a href="#">Business Banking</a></li>
                    <li><a href="#">Loans</a></li>
                    <li><a href="#">Investments</a></li>
                    <li><a href="#">Insurance</a></li>
                    <li><a href="#">Credit Cards</a></li>
                </ul>
            </div>
            
            <div class="footer-column">
                <h3>Contact Us</h3>
                <ul class="contact-info">
                    <li>
                        <i class="fas fa-map-marker-alt"></i>
                        <span>123 Banking Street, Financial District, Mumbai 400001</span>
                    </li>
                    <li>
                        <i class="fas fa-phone"></i>
                        <span>+91 22 1234 5678</span>
                    </li>
                    <li>
                        <i class="fas fa-envelope"></i>
                        <span>support@securebank.com</span>
                    </li>
                    <li>
                        <i class="fas fa-clock"></i>
                        <span>Mon-Fri: 9AM-6PM | Sat: 10AM-2PM</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <div class="copyright">
            <p>&copy; 2024 SecureBank. All rights reserved. | <a href="#" style="color: #2c5cc5;">Privacy Policy</a> | <a href="#" style="color: #2c5cc5;">Terms of Service</a></p>
            <p style="color: #b0b0b0; margin-top:8px; font-size:0.9rem;">Developed by University of Lahore Developers</p>
        </div>
    </footer>

    <script>
        // Mobile Menu Toggle
        const mobileMenuBtn = document.getElementById('mobileMenuBtn');
        const mainNav = document.getElementById('mainNav');
        
        mobileMenuBtn.addEventListener('click', () => {
            mainNav.classList.toggle('show');
            mobileMenuBtn.innerHTML = mainNav.classList.contains('show') 
                ? '<i class="fas fa-times"></i>' 
                : '<i class="fas fa-bars"></i>';
        });
        
        // Smooth scrolling for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                
                const targetId = this.getAttribute('href');
                if(targetId === '#') return;
                
                const targetElement = document.querySelector(targetId);
                if(targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80,
                        behavior: 'smooth'
                    });
                    
                    // Close mobile menu if open
                    if(mainNav.classList.contains('show')) {
                        mainNav.classList.remove('show');
                        mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
                    }
                }
            });
        });
        
        // Sticky header background on scroll
        window.addEventListener('scroll', () => {
            const header = document.querySelector('header');
            if(window.scrollY > 100) {
                header.style.backgroundColor = 'rgba(26, 58, 143, 0.95)';
                header.style.backdropFilter = 'blur(10px)';
            } else {
                header.style.backgroundColor = '';
                header.style.backdropFilter = '';
            }
        });
        
        // Animate elements on scroll
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if(entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Observe feature cards
        document.querySelectorAll('.feature-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
        
        // Observe testimonial cards
        document.querySelectorAll('.testimonial-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
        
        // Auto-hide mobile menu on resize
        window.addEventListener('resize', () => {
            if(window.innerWidth > 992 && mainNav.classList.contains('show')) {
                mainNav.classList.remove('show');
                mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
            }
        });
        
        // Demo credentials alert
        window.addEventListener('load', () => {
            setTimeout(() => {
                console.log('Demo Credentials:\nEmail: test@example.com\nPassword: test123');
            }, 1000);
        });

        // Quick demo login from index page
        function loginDemo() {
            const email = document.getElementById('demoEmail').textContent.trim();
            const pass = document.getElementById('demoPass').textContent.trim();
            document.getElementById('demo_form_email').value = email;
            document.getElementById('demo_form_password').value = pass;
            document.getElementById('demoLoginForm').submit();
        }
    </script>
</body>
</html>