
<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];

// Filter parameters
$filter_type = isset($_GET['type']) ? $_GET['type'] : '';
$filter_date = isset($_GET['date']) ? $_GET['date'] : '';
$filter_month = isset($_GET['month']) ? $_GET['month'] : '';
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Build query with filters
$sql = "SELECT * FROM transactions WHERE account_id = ?";
$params = [$account_id];
$param_types = "i";

// Add filters
if(!empty($filter_type) && $filter_type != 'all') {
    $sql .= " AND type = ?";
    $params[] = $filter_type;
    $param_types .= "s";
}

if(!empty($filter_date)) {
    $sql .= " AND DATE(created_at) = ?";
    $params[] = $filter_date;
    $param_types .= "s";
}

if(!empty($filter_month)) {
    $sql .= " AND MONTH(created_at) = MONTH(?) AND YEAR(created_at) = YEAR(?)";
    $params[] = $filter_month;
    $params[] = $filter_month;
    $param_types .= "ss";
}

if(!empty($search)) {
    $sql .= " AND (description LIKE ? OR type LIKE ?)";
    $search_term = "%$search%";
    $params[] = $search_term;
    $params[] = $search_term;
    $param_types .= "ss";
}

$sql .= " ORDER BY created_at DESC";

// Prepare and execute
$stmt = $conn->prepare($sql);

if(count($params) > 0) {
    $stmt->bind_param($param_types, ...$params);
}

$stmt->execute();
$transactions = $stmt->get_result();

// Calculate summary
$total_deposits = 0;
$total_withdrawals = 0;
$total_transfers = 0;

// Reset pointer and calculate
$transactions->data_seek(0);
while($transaction = $transactions->fetch_assoc()) {
    if($transaction['type'] == 'Deposit') {
        $total_deposits += $transaction['amount'];
    } elseif($transaction['type'] == 'Withdrawal') {
        $total_withdrawals += $transaction['amount'];
    } elseif($transaction['type'] == 'Transfer') {
        $total_transfers += $transaction['amount'];
    }
}
$transactions->data_seek(0); // Reset pointer again
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Transactions</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Summary Cards */
        .summary-cards {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .summary-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            display: flex;
            flex-direction: column;
        }
        
        .summary-icon {
            font-size: 1.8rem;
            margin-bottom: 15px;
        }
        
        .summary-title {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 5px;
        }
        
        .summary-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 10px;
        }
        
        .summary-change {
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .card-deposit {
            border-left: 4px solid #28a745;
        }
        
        .card-deposit .summary-icon {
            color: #28a745;
        }
        
        .card-withdrawal {
            border-left: 4px solid #dc3545;
        }
        
        .card-withdrawal .summary-icon {
            color: #dc3545;
        }
        
        .card-transfer {
            border-left: 4px solid #1a3a8f;
        }
        
        .card-transfer .summary-icon {
            color: #1a3a8f;
        }
        
        .card-balance {
            border-left: 4px solid #ffc107;
        }
        
        .card-balance .summary-icon {
            color: #ffc107;
        }
        
        /* Filters Section */
        .filters-section {
            background-color: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }
        
        .filters-title {
            font-size: 1.2rem;
            font-weight: 600;
            margin-bottom: 20px;
            color: #1a3a8f;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .filter-form {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        
        .filter-group {
            display: flex;
            flex-direction: column;
        }
        
        .filter-group label {
            font-weight: 600;
            margin-bottom: 8px;
            color: #333;
        }
        
        .filter-group input,
        .filter-group select {
            padding: 10px 12px;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            font-size: 0.95rem;
            transition: border-color 0.3s;
        }
        
        .filter-group input:focus,
        .filter-group select:focus {
            border-color: #1a3a8f;
            outline: none;
        }
        
        .filter-actions {
            display: flex;
            gap: 10px;
            align-items: flex-end;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 6px;
            font-size: 0.95rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background-color: #1a3a8f;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5cc5;
        }
        
        .btn-secondary {
            background-color: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-secondary:hover {
            background-color: #e9ecef;
        }
        
        /* Transactions Table */
        .transactions-section {
            background-color: white;
            border-radius: 10px;
            padding: 25px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
        }
        
        .section-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #1a3a8f;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .export-btn {
            background-color: #28a745;
            color: white;
            padding: 8px 15px;
            border-radius: 6px;
            text-decoration: none;
            font-size: 0.9rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .export-btn:hover {
            background-color: #218838;
        }
        
        .transactions-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .transactions-table thead {
            background-color: #f8f9fa;
        }
        
        .transactions-table th {
            text-align: left;
            padding: 15px;
            border-bottom: 2px solid #e0e0e0;
            color: #666;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .transactions-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .transaction-row:hover {
            background-color: #f8f9fa;
        }
        
        .transaction-type {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .type-icon {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.1rem;
        }
        
        .type-deposit {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .type-withdrawal {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .type-transfer {
            background-color: rgba(26, 58, 143, 0.1);
            color: #1a3a8f;
        }
        
        .transaction-details h4 {
            margin-bottom: 5px;
            font-weight: 600;
        }
        
        .transaction-details p {
            font-size: 0.9rem;
            color: #666;
        }
        
        .transaction-amount {
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .amount-positive {
            color: #28a745;
        }
        
        .amount-negative {
            color: #dc3545;
        }
        
        .transaction-date {
            color: #666;
            font-size: 0.9rem;
        }
        
        .transaction-balance {
            font-weight: 600;
            color: #333;
        }
        
        /* No Transactions */
        .no-transactions {
            text-align: center;
            padding: 50px 20px;
        }
        
        .no-transactions i {
            font-size: 3rem;
            color: #e0e0e0;
            margin-bottom: 20px;
            display: block;
        }
        
        .no-transactions h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .no-transactions p {
            color: #999;
        }
        
        /* Pagination */
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-top: 30px;
        }
        
        .page-link {
            padding: 8px 15px;
            background-color: #f8f9fa;
            border: 1px solid #e0e0e0;
            border-radius: 6px;
            text-decoration: none;
            color: #333;
            font-weight: 500;
        }
        
        .page-link:hover {
            background-color: #e9ecef;
        }
        
        .page-link.active {
            background-color: #1a3a8f;
            color: white;
            border-color: #1a3a8f;
        }
        
        /* Download Receipt */
        .download-receipt {
            color: #1a3a8f;
            text-decoration: none;
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .download-receipt:hover {
            text-decoration: underline;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .summary-cards {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .summary-cards {
                grid-template-columns: 1fr;
            }
            
            .filter-form {
                grid-template-columns: 1fr;
            }
            
            .filter-actions {
                flex-direction: column;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
            
            .transactions-table {
                display: block;
                overflow-x: auto;
            }
            
            .section-header {
                flex-direction: column;
                gap: 15px;
                align-items: flex-start;
            }
        }
        
        @media (max-width: 480px) {
            .transaction-type {
                flex-direction: column;
                align-items: flex-start;
                gap: 5px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transactions.php" class="nav-link active">
                    <i class="fas fa-history"></i>
                    <span>Transactions</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Transaction History</h2>
                <p>Account: <?php echo $account_number; ?> | User: <?php echo htmlspecialchars($full_name); ?></p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Summary Cards -->
        <div class="summary-cards">
            <div class="summary-card card-deposit">
                <i class="fas fa-arrow-down summary-icon"></i>
                <div class="summary-title">Total Deposits</div>
                <div class="summary-value">$<?php echo number_format($total_deposits, 2); ?></div>
                <div class="summary-change">
                    <i class="fas fa-arrow-up" style="color: #28a745;"></i>
                    <span>Last 30 days</span>
                </div>
            </div>
            
            <div class="summary-card card-withdrawal">
                <i class="fas fa-arrow-up summary-icon"></i>
                <div class="summary-title">Total Withdrawals</div>
                <div class="summary-value">$<?php echo number_format($total_withdrawals, 2); ?></div>
                <div class="summary-change">
                    <i class="fas fa-arrow-down" style="color: #dc3545;"></i>
                    <span>Last 30 days</span>
                </div>
            </div>
            
            <div class="summary-card card-transfer">
                <i class="fas fa-exchange-alt summary-icon"></i>
                <div class="summary-title">Total Transfers</div>
                <div class="summary-value">$<?php echo number_format($total_transfers, 2); ?></div>
                <div class="summary-change">
                    <i class="fas fa-arrows-alt-h" style="color: #1a3a8f;"></i>
                    <span>Last 30 days</span>
                </div>
            </div>
            
            <div class="summary-card card-balance">
                <i class="fas fa-wallet summary-icon"></i>
                <div class="summary-title">Current Balance</div>
                <div class="summary-value">$<?php echo number_format($current_balance, 2); ?></div>
                <div class="summary-change">
                    <i class="fas fa-chart-line" style="color: #ffc107;"></i>
                    <span>Updated now</span>
                </div>
            </div>
        </div>
        
        <!-- Filters Section -->
        <div class="filters-section">
            <h3 class="filters-title">
                <i class="fas fa-filter"></i>
                Filter Transactions
            </h3>
            
            <form method="GET" action="" class="filter-form">
                <div class="filter-group">
                    <label for="type">Transaction Type</label>
                    <select name="type" id="type">
                        <option value="all" <?php echo $filter_type == 'all' || $filter_type == '' ? 'selected' : ''; ?>>All Types</option>
                        <option value="Deposit" <?php echo $filter_type == 'Deposit' ? 'selected' : ''; ?>>Deposit</option>
                        <option value="Withdrawal" <?php echo $filter_type == 'Withdrawal' ? 'selected' : ''; ?>>Withdrawal</option>
                        <option value="Transfer" <?php echo $filter_type == 'Transfer' ? 'selected' : ''; ?>>Transfer</option>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label for="date">Specific Date</label>
                    <input type="date" name="date" id="date" value="<?php echo $filter_date; ?>">
                </div>
                
                <div class="filter-group">
                    <label for="month">Month</label>
                    <input type="month" name="month" id="month" value="<?php echo $filter_month; ?>">
                </div>
                
                <div class="filter-group">
                    <label for="search">Search Description</label>
                    <input type="text" name="search" id="search" placeholder="Search transactions..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                
                <div class="filter-actions">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-search"></i> Apply Filters
                    </button>
                    <a href="transactions.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Clear Filters
                    </a>
                </div>
            </form>
        </div>
        
        <!-- Transactions Section -->
        <div class="transactions-section">
            <div class="section-header">
                <h3 class="section-title">
                    <i class="fas fa-list"></i>
                    Transaction History
                </h3>
                
                <a href="#" class="export-btn" onclick="downloadStatement()">
                    <i class="fas fa-download"></i> Download Statement
                </a>
            </div>
            
            <?php if($transactions->num_rows > 0): ?>
            <div style="overflow-x: auto;">
                <table class="transactions-table">
                    <thead>
                        <tr>
                            <th>Transaction</th>
                            <th>Date & Time</th>
                            <th>Amount</th>
                            <th>Balance After</th>
                            <th>Receipt</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($transaction = $transactions->fetch_assoc()): ?>
                        <tr class="transaction-row">
                            <td>
                                <div class="transaction-type">
                                    <div class="type-icon type-<?php echo strtolower($transaction['type']); ?>">
                                        <i class="fas <?php 
                                            if($transaction['type'] == 'Deposit') echo 'fa-arrow-down';
                                            elseif($transaction['type'] == 'Withdrawal') echo 'fa-arrow-up';
                                            else echo 'fa-exchange-alt';
                                        ?>"></i>
                                    </div>
                                    <div class="transaction-details">
                                        <h4><?php echo htmlspecialchars($transaction['type']); ?></h4>
                                        <p><?php echo htmlspecialchars($transaction['description']); ?></p>
                                    </div>
                                </div>
                            </td>
                            <td class="transaction-date">
                                <?php echo date('M j, Y', strtotime($transaction['created_at'])); ?><br>
                                <small><?php echo date('h:i A', strtotime($transaction['created_at'])); ?></small>
                            </td>
                            <td class="transaction-amount <?php echo $transaction['type'] == 'Deposit' ? 'amount-positive' : 'amount-negative'; ?>">
                                <?php echo ($transaction['type'] == 'Deposit' ? '+' : '-') . '$' . number_format($transaction['amount'], 2); ?>
                            </td>
                            <td class="transaction-balance">
                                $<?php echo number_format($transaction['balance_after'], 2); ?>
                            </td>
                            <td>
                                <a href="#" class="download-receipt" onclick="downloadReceipt(<?php echo $transaction['id']; ?>)">
                                    <i class="fas fa-receipt"></i> Receipt
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination (Demo) -->
            <div class="pagination">
                <a href="#" class="page-link"><i class="fas fa-chevron-left"></i></a>
                <a href="#" class="page-link active">1</a>
                <a href="#" class="page-link">2</a>
                <a href="#" class="page-link">3</a>
                <a href="#" class="page-link"><i class="fas fa-chevron-right"></i></a>
            </div>
            
            <?php else: ?>
            <div class="no-transactions">
                <i class="fas fa-receipt"></i>
                <h3>No transactions found</h3>
                <p><?php 
                    if($filter_type || $filter_date || $filter_month || $search) {
                        echo "Try changing your filters or search criteria.";
                    } else {
                        echo "You haven't made any transactions yet.";
                    }
                ?></p>
                <?php if($filter_type || $filter_date || $filter_month || $search): ?>
                <a href="transactions.php" class="btn btn-primary" style="margin-top: 20px; display: inline-block;">
                    <i class="fas fa-times"></i> Clear Filters
                </a>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Set today's date as max for date picker
        document.getElementById('date').max = new Date().toISOString().split('T')[0];
        document.getElementById('month').max = new Date().toISOString().split('T')[0].substring(0, 7);
        
        // Download receipt function
        function downloadReceipt(transactionId) {
            alert('Downloading receipt for transaction #' + transactionId + '\n\nIn a real application, this would generate a PDF receipt.');
            // In real app: window.location.href = 'generate_receipt.php?id=' + transactionId;
        }
        
        // Download statement function
        function downloadStatement() {
            const type = document.getElementById('type').value;
            const date = document.getElementById('date').value;
            const month = document.getElementById('month').value;
            const search = document.getElementById('search').value;
            
            let params = [];
            if(type && type !== 'all') params.push('type=' + type);
            if(date) params.push('date=' + date);
            if(month) params.push('month=' + month);
            if(search) params.push('search=' + encodeURIComponent(search));
            
            const queryString = params.length ? '?' + params.join('&') : '';
            
            alert('Downloading bank statement' + queryString + '\n\nIn a real application, this would generate a PDF statement.');
            // In real app: window.location.href = 'generate_statement.php' + queryString;
        }
        
        // Auto-submit form when month is selected
        document.getElementById('month').addEventListener('change', function() {
            if(this.value) {
                document.getElementById('date').value = ''; // Clear date if month is selected
            }
        });
        
        // Auto-submit form when date is selected
        document.getElementById('date').addEventListener('change', function() {
            if(this.value) {
                document.getElementById('month').value = ''; // Clear month if date is selected
            }
        });
        
        // Print button functionality
        function printStatement() {
            window.print();
        }
        
        // Add print button dynamically
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('.section-header');
            if(header) {
                const printBtn = document.createElement('a');
                printBtn.href = '#';
                printBtn.className = 'export-btn';
                printBtn.innerHTML = '<i class="fas fa-print"></i> Print';
                printBtn.style.marginRight = '10px';
                printBtn.onclick = printStatement;
                header.insertBefore(printBtn, header.querySelector('.export-btn'));
            }
        });
    </script>
</body>
</html>
