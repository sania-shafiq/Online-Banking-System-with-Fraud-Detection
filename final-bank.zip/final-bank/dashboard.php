<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];

// Get recent transactions
$recent_transactions = getRecentTransactions($conn, $account_id, 5);

// Get total loan
$total_loan = getTotalLoan($conn, $account_id);

// Calculate available balance (excluding loan amount if needed)
$available_balance = $current_balance;
$savings = $current_balance * 0.3; // Example: 30% as savings
$credit_limit = 15000.00; // Fixed credit limit
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .notification {
            position: relative;
            cursor: pointer;
        }
        
        .notification i {
            font-size: 1.5rem;
            color: #666;
        }
        
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            background-color: #dc3545;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 0.8rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Balance Card */
        .balance-card {
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(26, 58, 143, 0.2);
            margin-bottom: 25px;
            position: relative;
            overflow: hidden;
        }
        
        .balance-card::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .balance-content {
            position: relative;
            z-index: 1;
        }
        
        .balance-label {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .balance-amount {
            font-size: 3.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .balance-details {
            display: flex;
            gap: 30px;
            margin-top: 25px;
        }
        
        .balance-detail-item {
            display: flex;
            flex-direction: column;
        }
        
        .detail-label {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-size: 1.4rem;
            font-weight: 600;
        }
        
        /* Quick Actions */
        .quick-actions {
            background-color: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 25px;
        }
        
        .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 25px;
            color: #1a3a8f;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .section-title i {
            color: #2c5cc5;
        }
        
        .action-buttons {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            padding: 18px 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
        }
        
        .action-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        
        .action-btn i {
            font-size: 1.3rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .deposit-btn i {
            color: #28a745;
        }
        
        .transaction-btn i {
            color: #1a3a8f;
        }
        
        .loan-btn i {
            color: #2c5cc5;
        }
        
        /* Account Info */
        .account-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }
        
        .info-item {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
        }
        
        .info-label {
            color: #666;
        }
        
        .info-value {
            font-weight: 600;
        }
        
        /* Recent Transactions */
        .recent-transactions {
            background-color: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .table-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .view-all {
            color: #1a3a8f;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        .transactions-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .transactions-table th {
            text-align: left;
            padding: 15px 10px;
            border-bottom: 2px solid #e0e0e0;
            color: #666;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        .transactions-table td {
            padding: 15px 10px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .transaction-type {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .transaction-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        .deposit-icon {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .withdrawal-icon {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .transfer-icon {
            background-color: rgba(26, 58, 143, 0.1);
            color: #1a3a8f;
        }
        
        .transaction-name {
            font-weight: 500;
        }
        
        .transaction-date {
            color: #666;
            font-size: 0.9rem;
        }
        
        .transaction-amount {
            font-weight: 600;
            font-size: 1.1rem;
        }
        
        .positive {
            color: #28a745;
        }
        
        .negative {
            color: #dc3545;
        }
        
        .no-transactions {
            text-align: center;
            padding: 30px;
            color: #666;
        }
        
        .no-transactions i {
            font-size: 2rem;
            margin-bottom: 10px;
            display: block;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
        }
        
        @media (max-width: 768px) {
            .balance-amount {
                font-size: 2.5rem;
            }
            
            .balance-details {
                flex-direction: column;
                gap: 15px;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
            
            .action-buttons {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link active">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transactions.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transactions</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Welcome back, <?php echo htmlspecialchars($full_name); ?>!</h2>
                <p>Account: <?php echo $account_number; ?> | Last login: <?php echo date('F j, Y, g:i A'); ?></p>
            </div>
            
            <div class="user-info">
                <div class="notification">
                    <i class="fas fa-bell"></i>
                    <span class="notification-badge">3</span>
                </div>
                
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Current Balance Card -->
        <div class="balance-card">
            <div class="balance-content">
                <div class="balance-label">CURRENT BALANCE</div>
                <div class="balance-amount">$<?php echo number_format($current_balance, 2); ?></div>
                
                <div class="balance-details">
                    <div class="balance-detail-item">
                        <div class="detail-label">Available Balance</div>
                        <div class="detail-value">$<?php echo number_format($available_balance, 2); ?></div>
                    </div>
                    <div class="balance-detail-item">
                        <div class="detail-label">Account Number</div>
                        <div class="detail-value"><?php echo $account_number; ?></div>
                    </div>
                    <div class="balance-detail-item">
                        <div class="detail-label">Savings</div>
                        <div class="detail-value">$<?php echo number_format($savings, 2); ?></div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="quick-actions">
            <h3 class="section-title">
                <i class="fas fa-bolt"></i>
                Quick Actions
            </h3>
            
            <div class="action-buttons">
                <a href="deposit.php" class="action-btn deposit-btn">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit Money</span>
                </a>
                
                <a href="withdraw.php" class="action-btn transaction-btn">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw Money</span>
                </a>
                
                <a href="transfer.php" class="action-btn transaction-btn">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer Money</span>
                </a>
                
                <a href="loan.php" class="action-btn loan-btn">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Apply for Loan</span>
                </a>
            </div>
            
            <!-- Account Info -->
            <div class="account-info">
                <div class="info-item">
                    <span class="info-label">Credit Limit:</span>
                    <span class="info-value">$<?php echo number_format($credit_limit, 2); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Active Loans:</span>
                    <span class="info-value" style="color: #dc3545;">$<?php echo number_format($total_loan, 2); ?></span>
                </div>
                <div class="info-item">
                    <span class="info-label">Account Type:</span>
                    <span class="info-value">Savings Account</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Status:</span>
                    <span class="info-value" style="color: #28a745;">Active</span>
                </div>
            </div>
        </div>
        
        <!-- Recent Transactions -->
        <div class="recent-transactions">
            <div class="table-header">
                <h3 class="section-title">
                    <i class="fas fa-history"></i>
                    Recent Transactions
                </h3>
                <a href="transactions.php" class="view-all">View All Transactions</a>
            </div>
            
            <?php if($recent_transactions->num_rows > 0): ?>
            <table class="transactions-table">
                <thead>
                    <tr>
                        <th>Transaction</th>
                        <th>Date</th>
                        <th>Amount</th>
                        <th>Balance After</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($transaction = $recent_transactions->fetch_assoc()): ?>
                    <tr>
                        <td>
                            <div class="transaction-type">
                                <div class="transaction-icon <?php 
                                    if($transaction['type'] == 'Deposit') echo 'deposit-icon';
                                    elseif($transaction['type'] == 'Withdrawal') echo 'withdrawal-icon';
                                    else echo 'transfer-icon';
                                ?>">
                                    <i class="fas <?php 
                                        if($transaction['type'] == 'Deposit') echo 'fa-arrow-down';
                                        elseif($transaction['type'] == 'Withdrawal') echo 'fa-arrow-up';
                                        else echo 'fa-exchange-alt';
                                    ?>"></i>
                                </div>
                                <div>
                                    <div class="transaction-name"><?php echo htmlspecialchars($transaction['type']); ?></div>
                                    <div class="transaction-description"><?php echo htmlspecialchars($transaction['description']); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="transaction-date"><?php echo date('M j, Y', strtotime($transaction['created_at'])); ?></td>
                        <td class="transaction-amount <?php echo $transaction['type'] == 'Deposit' ? 'positive' : 'negative'; ?>">
                            <?php echo ($transaction['type'] == 'Deposit' ? '+' : '-') . '$' . number_format($transaction['amount'], 2); ?>
                        </td>
                        <td style="font-weight: 600;">$<?php echo number_format($transaction['balance_after'], 2); ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
            <?php else: ?>
            <div class="no-transactions">
                <i class="fas fa-history"></i>
                <p>No transactions yet</p>
                <p style="margin-top: 10px; font-size: 0.9rem;">Make your first deposit or transfer!</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Notification bell click
        document.querySelector('.notification').addEventListener('click', () => {
            alert('You have 3 new notifications:\n1. Payment received\n2. Loan application under review\n3. Monthly statement ready');
        });
    </script>
</body>
</html>