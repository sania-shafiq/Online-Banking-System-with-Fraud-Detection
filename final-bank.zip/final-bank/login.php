
<?php
session_start();
include 'db.php';

// Redirect if already logged in
if(isset($_SESSION['user_id'])) {
    header("Location: dashboard.php");
    exit();
}

$error_message = '';

// Process login
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $email = $conn->real_escape_string($_POST['email']);
    $password = $_POST['password'];
    
    // Validate input
    if(empty($email) || empty($password)) {
        $error_message = "Please enter both email and password!";
    } else {
        // Check if user exists and verify password
        if(loginUser($conn, $email, $password)) {
            header("Location: dashboard.php");
            exit();
        } else {
            $error_message = "Invalid email or password!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Login</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            width: 100%;
            max-width: 450px;
            animation: fadeIn 0.8s ease-out;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Logo Header */
        .logo-header {
            text-align: center;
            margin-bottom: 30px;
            color: white;
        }
        
        .logo-header i {
            font-size: 3.5rem;
            margin-bottom: 15px;
            display: block;
        }
        
        .logo-header h1 {
            font-size: 2.2rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .logo-header p {
            opacity: 0.9;
            font-size: 1rem;
        }
        
        /* Login Card */
        .login-card {
            background-color: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
        }
        
        .card-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .card-header h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
            margin-bottom: 10px;
        }
        
        .card-header p {
            color: #666;
            font-size: 0.95rem;
        }
        
        /* Error Message */
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 12px 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: slideDown 0.3s ease-out;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .error-message i {
            font-size: 1.2rem;
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-group i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
            font-size: 1.1rem;
        }
        
        .form-control {
            width: 100%;
            padding: 14px 15px 14px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 1rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: #1a3a8f;
            outline: none;
            box-shadow: 0 0 0 3px rgba(26, 58, 143, 0.1);
        }
        
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 1.1rem;
        }
        
        /* Remember Me & Forgot Password */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .remember-me {
            display: flex;
            align-items: center;
            gap: 8px;
        }
        
        .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }
        
        .remember-me label {
            color: #666;
            font-size: 0.95rem;
            cursor: pointer;
        }
        
        .forgot-password {
            color: #1a3a8f;
            text-decoration: none;
            font-size: 0.95rem;
            font-weight: 500;
        }
        
        .forgot-password:hover {
            text-decoration: underline;
        }
        
        /* Submit Button */
        .submit-btn {
            width: 100%;
            padding: 16px;
            background: linear-gradient(to right, #1a3a8f, #2c5cc5);
            color: white;
            border: none;
            border-radius: 10px;
            font-size: 1.1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            margin-bottom: 25px;
        }
        
        .submit-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(26, 58, 143, 0.2);
        }
        
        .submit-btn:active {
            transform: translateY(0);
        }
        
        /* Divider */
        .divider {
            display: flex;
            align-items: center;
            margin: 25px 0;
            color: #999;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background-color: #e0e0e0;
        }
        
        .divider span {
            padding: 0 15px;
            font-size: 0.9rem;
        }
        
        /* Register Link */
        .register-link {
            text-align: center;
            margin-top: 25px;
            padding-top: 25px;
            border-top: 1px solid #e0e0e0;
        }
        
        .register-link p {
            color: #666;
            margin-bottom: 10px;
        }
        
        .register-btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: #f8f9fa;
            color: #1a3a8f;
            border: 2px solid #1a3a8f;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        
        .register-btn:hover {
            background-color: #1a3a8f;
            color: white;
        }
        
        /* Demo Credentials */
        .demo-credentials {
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            margin-top: 25px;
            border-left: 4px solid #28a745;
        }
        
        .demo-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            color: #155724;
        }
        
        .demo-header i {
            font-size: 1.2rem;
        }
        
        .demo-content {
            font-size: 0.9rem;
            color: #666;
        }
        
        .demo-content strong {
            color: #155724;
        }
        
        /* Responsive */
        @media (max-width: 576px) {
            .login-card {
                padding: 30px 25px;
            }
            
            .logo-header h1 {
                font-size: 1.8rem;
            }
            
            .card-header h2 {
                font-size: 1.5rem;
            }
            
            .form-options {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .demo-credentials {
                padding: 15px;
            }
        }
        
        @media (max-width: 400px) {
            .logo-header i {
                font-size: 2.8rem;
            }
            
            .logo-header h1 {
                font-size: 1.6rem;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <!-- Logo Header -->
        <div class="logo-header">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
            <p>Your Trusted Banking Partner</p>
        </div>
        
        <!-- Login Card -->
        <div class="login-card">
            <!-- Card Header -->
            <div class="card-header">
                <h2>Welcome Back</h2>
                <p>Sign in to access your account</p>
            </div>
            
            <!-- Error Message -->
            <?php if($error_message): ?>
            <div class="error-message">
                <i class="fas fa-exclamation-circle"></i>
                <?php echo htmlspecialchars($error_message); ?>
            </div>
            <?php endif; ?>
            
            <!-- Login Form -->
            <form method="POST" action="" id="loginForm">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <div class="input-group">
                        <i class="fas fa-envelope"></i>
                        <input type="email" name="email" id="email" class="form-control" 
                               placeholder="Enter your email" required
                               value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" name="password" id="password" class="form-control" 
                               placeholder="Enter your password" required>
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
                
                <div class="form-options">
                    <div class="remember-me">
                        <input type="checkbox" id="remember" name="remember">
                        <label for="remember">Remember me</label>
                    </div>
                    <a href="#" class="forgot-password" onclick="forgotPassword()">Forgot Password?</a>
                </div>
                
                <button type="submit" name="login" class="submit-btn">
                    <i class="fas fa-sign-in-alt"></i>
                    Sign In
                </button>
                
                <!-- Divider -->
                <div class="divider">
                    <span>or</span>
                </div>
                
                <!-- Demo Credentials -->
                <div class="demo-credentials">
                    <div class="demo-header">
                        <i class="fas fa-info-circle"></i>
                        <h3>Demo Credentials</h3>
                    </div>
                    <div class="demo-content">
                        <p>Use these credentials to test the system:</p>
                        <p><strong>Email:</strong> test@example.com</p>
                        <p><strong>Password:</strong> password</p>
                    </div>
                </div>
            </form>
            
            <!-- Register Link -->
            <div class="register-link">
                <p>Don't have an account?</p>
                <a href="register.php" class="register-btn">
                    <i class="fas fa-user-plus"></i>
                    Create New Account
                </a>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.querySelector('.password-toggle i');
            
            if(passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('fa-eye');
                toggleIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('fa-eye-slash');
                toggleIcon.classList.add('fa-eye');
            }
        }
        
        // Forgot password functionality
        function forgotPassword() {
            const email = document.getElementById('email').value;
            
            if(email) {
                alert('Password reset link has been sent to: ' + email + '\n\n(In real application, this would send a reset email)');
            } else {
                alert('Please enter your email address first to reset password.');
                document.getElementById('email').focus();
            }
        }
        
        // Form validation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            // Basic email validation
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailRegex.test(email)) {
                alert('Please enter a valid email address!');
                e.preventDefault();
                return;
            }
            
            // Password length validation
            if(password.length < 6) {
                alert('Password must be at least 6 characters long!');
                e.preventDefault();
            }
        });
        
        // Auto-focus email field on page load
        document.addEventListener('DOMContentLoaded', function() {
            const emailField = document.getElementById('email');
            if(emailField.value === '') {
                emailField.focus();
            }
        });
        
        // Enter key submits form
        document.addEventListener('keydown', function(e) {
            if(e.key === 'Enter' && document.activeElement.tagName !== 'TEXTAREA') {
                const form = document.getElementById('loginForm');
                const submitButton = form.querySelector('button[type="submit"]');
                submitButton.click();
            }
        });
        
        // Remember me functionality (local storage)
        document.addEventListener('DOMContentLoaded', function() {
            const rememberCheckbox = document.getElementById('remember');
            const emailField = document.getElementById('email');
            
            // Load saved email if remember me was checked
            const savedEmail = localStorage.getItem('rememberedEmail');
            if(savedEmail) {
                emailField.value = savedEmail;
                rememberCheckbox.checked = true;
            }
            
            // Save email when checkbox is checked
            rememberCheckbox.addEventListener('change', function() {
                if(this.checked && emailField.value) {
                    localStorage.setItem('rememberedEmail', emailField.value);
                } else {
                    localStorage.removeItem('rememberedEmail');
                }
            });
        });
    </script>
</body>
</html>
