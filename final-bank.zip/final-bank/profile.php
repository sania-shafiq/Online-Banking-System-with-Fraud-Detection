
<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

// Get user account
$account = getUserAccount($conn, $user_id);
$account_number = $account['account_number'];

$message = '';
$success = false;

// Process profile update
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $new_full_name = $conn->real_escape_string($_POST['full_name']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $address = $conn->real_escape_string($_POST['address']);
    
    // Update user details
    $sql = "UPDATE users SET full_name = ?, phone = ?, address = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $new_full_name, $phone, $address, $user_id);
    
    if($stmt->execute()) {
        $_SESSION['full_name'] = $new_full_name;
        $full_name = $new_full_name;
        $user['full_name'] = $new_full_name;
        $user['phone'] = $phone;
        $user['address'] = $address;
        
        $message = "Profile updated successfully!";
        $success = true;
    } else {
        $message = "Error updating profile. Please try again.";
    }
}

// Process password change
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate passwords
    if($new_password !== $confirm_password) {
        $message = "New passwords do not match!";
    } elseif(strlen($new_password) < 6) {
        $message = "Password must be at least 6 characters long!";
    } else {
        // Verify current password
        if(password_verify($current_password, $user['password'])) {
            // Update password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET password = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $hashed_password, $user_id);
            
            if($stmt->execute()) {
                $message = "Password changed successfully!";
                $success = true;
            } else {
                $message = "Error changing password. Please try again.";
            }
        } else {
            $message = "Current password is incorrect!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Profile</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Message Box */
        .message-box {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Profile Container */
        .profile-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Profile Card */
        .profile-card {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .card-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .card-header i {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .card-header h3 {
            font-size: 1.4rem;
            font-weight: 600;
            color: #1a3a8f;
        }
        
        /* Profile Info */
        .profile-info {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
            margin-bottom: 30px;
        }
        
        .profile-avatar {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 2.5rem;
            font-weight: bold;
            margin-bottom: 20px;
            border: 5px solid white;
            box-shadow: 0 5px 15px rgba(26, 58, 143, 0.2);
        }
        
        .profile-name {
            font-size: 1.8rem;
            font-weight: 600;
            margin-bottom: 5px;
            color: #333;
        }
        
        .profile-email {
            color: #666;
            margin-bottom: 15px;
        }
        
        .profile-role {
            background-color: #f8f9fa;
            color: #1a3a8f;
            padding: 5px 15px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
        }
        
        /* Account Stats */
        .account-stats {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #f0f0f0;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1a3a8f;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        /* Form Styles */
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #1a3a8f;
            outline: none;
        }
        
        .form-group textarea {
            resize: vertical;
            min-height: 100px;
        }
        
        /* Password Input Group */
        .password-input-group {
            position: relative;
        }
        
        .password-toggle {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #666;
            cursor: pointer;
            font-size: 1.1rem;
        }
        
        /* Form Actions */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }
        
        .btn-primary {
            background-color: #1a3a8f;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2c5cc5;
        }
        
        .btn-secondary {
            background-color: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-secondary:hover {
            background-color: #e9ecef;
        }
        
        /* Security Info */
        .security-info {
            background-color: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
        }
        
        .security-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .security-item:last-child {
            border-bottom: none;
        }
        
        .security-status {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 600;
        }
        
        .status-active {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .status-inactive {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        /* Account Details */
        .account-details-list {
            list-style: none;
        }
        
        .account-detail-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .account-detail-item:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            color: #666;
            font-weight: 500;
        }
        
        .detail-value {
            font-weight: 600;
            text-align: right;
        }
        
        /* Danger Zone */
        .danger-zone {
            background-color: #f8d7da;
            border: 2px solid #f5c6cb;
            border-radius: 10px;
            padding: 25px;
            margin-top: 30px;
        }
        
        .danger-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 15px;
            color: #721c24;
        }
        
        .danger-header i {
            font-size: 1.5rem;
        }
        
        .danger-actions {
            display: flex;
            gap: 15px;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .profile-container {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .account-stats {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
            
            .danger-actions {
                flex-direction: column;
            }
        }
        
        @media (max-width: 480px) {
            .profile-avatar {
                width: 100px;
                height: 100px;
                font-size: 2rem;
            }
            
            .profile-name {
                font-size: 1.5rem;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transactions.php" class="nav-link">
                    <i class="fas fa-history"></i>
                    <span>Transactions</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link active">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>My Profile</h2>
                <p>Manage your account settings and personal information</p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Message Box -->
        <?php if($message): ?>
        <div class="message-box <?php echo $success ? 'success' : 'error'; ?>">
            <i class="fas <?php echo $success ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
        </div>
        <?php endif; ?>
        
        <div class="profile-container">
            <!-- Left Column: Profile Info -->
            <div class="profile-card">
                <div class="profile-info">
                    <div class="profile-avatar"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div class="profile-name"><?php echo htmlspecialchars($full_name); ?></div>
                    <div class="profile-email"><?php echo htmlspecialchars($user['email']); ?></div>
                    <div class="profile-role">Premium Banking Member</div>
                </div>
                
                <div class="account-stats">
                    <div class="stat-item">
                        <div class="stat-value"><?php echo date('M Y', strtotime($user['created_at'])); ?></div>
                        <div class="stat-label">Member Since</div>
                    </div>
                    <div class="stat-item">
                        <div class="stat-value"><?php echo $account_number; ?></div>
                        <div class="stat-label">Account Number</div>
                    </div>
                </div>
                
                <!-- Account Details -->
                <div class="card-header">
                    <i class="fas fa-info-circle"></i>
                    <h3>Account Details</h3>
                </div>
                
                <ul class="account-details-list">
                    <li class="account-detail-item">
                        <span class="detail-label">Account Status</span>
                        <span class="detail-value status-active">Active</span>
                    </li>
                    <li class="account-detail-item">
                        <span class="detail-label">Account Type</span>
                        <span class="detail-value">Savings Account</span>
                    </li>
                    <li class="account-detail-item">
                        <span class="detail-label">Last Login</span>
                        <span class="detail-value"><?php echo date('F j, Y, g:i A'); ?></span>
                    </li>
                    <li class="account-detail-item">
                        <span class="detail-label">Email Verified</span>
                        <span class="detail-value status-active">Verified</span>
                    </li>
                    <li class="account-detail-item">
                        <span class="detail-label">Phone Verified</span>
                        <span class="detail-value <?php echo !empty($user['phone']) ? 'status-active' : 'status-inactive'; ?>">
                            <?php echo !empty($user['phone']) ? 'Verified' : 'Not Verified'; ?>
                        </span>
                    </li>
                </ul>
                
                <!-- Security Information -->
                <div class="security-info">
                    <div class="card-header" style="border-bottom: none; margin-bottom: 15px; padding-bottom: 0;">
                        <i class="fas fa-shield-alt"></i>
                        <h3 style="font-size: 1.2rem;">Security</h3>
                    </div>
                    
                    <div class="security-item">
                        <span>Two-Factor Authentication</span>
                        <span class="security-status status-inactive">Disabled</span>
                    </div>
                    <div class="security-item">
                        <span>Login Notifications</span>
                        <span class="security-status status-active">Enabled</span>
                    </div>
                    <div class="security-item">
                        <span>Password Last Changed</span>
                        <span><?php echo date('M j, Y', strtotime($user['created_at'])); ?></span>
                    </div>
                </div>
            </div>
            
            <!-- Right Column: Forms -->
            <div>
                <!-- Edit Profile Form -->
                <div class="profile-card">
                    <div class="card-header">
                        <i class="fas fa-user-edit"></i>
                        <h3>Edit Profile</h3>
                    </div>
                    
                    <form method="POST" action="">
                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" name="full_name" id="full_name" 
                                   value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email Address</label>
                            <input type="email" name="email" id="email" 
                                   value="<?php echo htmlspecialchars($user['email']); ?>" disabled 
                                   style="background-color: #f8f9fa; cursor: not-allowed;">
                            <small style="color: #666; display: block; margin-top: 5px;">Email cannot be changed</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" name="phone" id="phone" 
                                   value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>" 
                                   placeholder="Enter your phone number">
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Address</label>
                            <textarea name="address" id="address" 
                                      placeholder="Enter your complete address"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="update_profile" class="btn btn-primary">
                                <i class="fas fa-save"></i> Save Changes
                            </button>
                            <button type="reset" class="btn btn-secondary">
                                <i class="fas fa-undo"></i> Reset
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Change Password Form -->
                <div class="profile-card">
                    <div class="card-header">
                        <i class="fas fa-key"></i>
                        <h3>Change Password</h3>
                    </div>
                    
                    <form method="POST" action="" id="passwordForm">
                        <div class="form-group">
                            <label for="current_password">Current Password</label>
                            <div class="password-input-group">
                                <input type="password" name="current_password" id="current_password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('current_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="new_password">New Password</label>
                            <div class="password-input-group">
                                <input type="password" name="new_password" id="new_password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('new_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="confirm_password">Confirm New Password</label>
                            <div class="password-input-group">
                                <input type="password" name="confirm_password" id="confirm_password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('confirm_password')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                            <small style="color: #666; display: block; margin-top: 5px;">Password must be at least 6 characters long</small>
                        </div>
                        
                        <div class="form-actions">
                            <button type="submit" name="change_password" class="btn btn-primary">
                                <i class="fas fa-key"></i> Change Password
                            </button>
                        </div>
                    </form>
                </div>
                
                <!-- Danger Zone -->
                <div class="danger-zone">
                    <div class="danger-header">
                        <i class="fas fa-exclamation-triangle"></i>
                        <h3>Danger Zone</h3>
                    </div>
                    
                    <p style="color: #721c24; margin-bottom: 20px;">
                        These actions are irreversible. Please proceed with caution.
                    </p>
                    
                    <div class="danger-actions">
                        <button type="button" class="btn btn-danger" onclick="confirmDeactivate()">
                            <i class="fas fa-user-slash"></i> Deactivate Account
                        </button>
                        
                        <button type="button" class="btn btn-secondary" onclick="confirmLogoutAll()">
                            <i class="fas fa-sign-out-alt"></i> Logout All Devices
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Toggle password visibility
        function togglePassword(inputId) {
            const input = document.getElementById(inputId);
            const toggleBtn = input.parentElement.querySelector('.password-toggle i');
            
            if(input.type === 'password') {
                input.type = 'text';
                toggleBtn.classList.remove('fa-eye');
                toggleBtn.classList.add('fa-eye-slash');
            } else {
                input.type = 'password';
                toggleBtn.classList.remove('fa-eye-slash');
                toggleBtn.classList.add('fa-eye');
            }
        }
        
        // Password validation
        document.getElementById('passwordForm').addEventListener('submit', function(e) {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if(newPassword.length < 6) {
                alert('Password must be at least 6 characters long!');
                e.preventDefault();
                return;
            }
            
            if(newPassword !== confirmPassword) {
                alert('New passwords do not match!');
                e.preventDefault();
                return;
            }
            
            if(!confirm('Are you sure you want to change your password?')) {
                e.preventDefault();
            }
        });
        
        // Confirm account deactivation
        function confirmDeactivate() {
            if(confirm('Are you sure you want to deactivate your account?\n\nThis action will: \n• Freeze your account\n• Cancel all pending transactions\n• You will need to contact support to reactivate\n\nThis action cannot be undone!')) {
                alert('Account deactivation request sent to support.\n\nIn a real application, this would send a request to administrators.');
            }
        }
        
        // Confirm logout from all devices
        function confirmLogoutAll() {
            if(confirm('Are you sure you want to logout from all devices?\n\nThis will sign you out from: \n• This browser\n• Mobile app\n• Any other active sessions\n\nYou will need to login again on all devices.')) {
                alert('Logged out from all devices.\n\nIn a real application, this would invalidate all sessions.');
                // In real app: window.location.href = 'logout_all.php';
            }
        }
        
        // Profile form validation
        document.querySelector('form[name="update_profile"]').addEventListener('submit', function(e) {
            const phone = document.getElementById('phone').value;
            const phoneRegex = /^[\+]?[0-9\s\-\(\)]{10,}$/;
            
            if(phone && !phoneRegex.test(phone)) {
                alert('Please enter a valid phone number!');
                e.preventDefault();
            }
        });
        
        // Auto-format phone number
        document.getElementById('phone').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if(value.length > 3 && value.length <= 6) {
                value = value.replace(/(\d{3})(\d+)/, '$1-$2');
            } else if(value.length > 6) {
                value = value.replace(/(\d{3})(\d{3})(\d+)/, '$1-$2-$3');
            }
            e.target.value = value;
        });
        
        // Profile image upload simulation
        document.querySelector('.profile-avatar').addEventListener('click', function() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = 'image/*';
            input.onchange = function(e) {
                const file = e.target.files[0];
                if(file) {
                    if(file.size > 5 * 1024 * 1024) { // 5MB limit
                        alert('Image size should be less than 5MB');
                        return;
                    }
                    
                    const reader = new FileReader();
                    reader.onload = function(event) {
                        const avatar = document.querySelector('.profile-avatar');
                        avatar.style.backgroundImage = `url(${event.target.result})`;
                        avatar.style.backgroundSize = 'cover';
                        avatar.style.backgroundPosition = 'center';
                        avatar.textContent = '';
                        avatar.innerHTML = '<i class="fas fa-camera"></i>';
                        
                        alert('Profile picture updated! (In real app, this would save to server)');
                    };
                    reader.readAsDataURL(file);
                }
            };
            input.click();
        });
    </script>
</body>
</html>

