<?php
// Simple DB check endpoint for debugging
include 'db.php';

try {
    echo "DB connection OK.<br>";

    $stmt = $conn->prepare("SELECT COUNT(*) as c FROM users");
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    echo "Users in DB: " . ($row['c'] ?? 0) . "<br>";

    $stmt2 = $conn->prepare("SELECT id, full_name, email FROM users LIMIT 5");
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    $rows = $res2->fetch_all(MYSQLI_ASSOC);

    echo "<h3>Sample users</h3>";
    echo '<pre>' . htmlspecialchars(print_r($rows, true)) . '</pre>';
} catch (Exception $e) {
    echo "Error: " . htmlspecialchars($e->getMessage());
}

echo "<p>Note: If you run the site under XAMPP, open <a href=\"/check_db.php\">http://localhost/check_db.php</a>.\n";
echo "If using PHP built-in server from the project folder, run: <code>php -S localhost:8000</code> and open <a href=\"http://localhost:8000/check_db.php\">http://localhost:8000/check_db.php</a>.</p>";
?>