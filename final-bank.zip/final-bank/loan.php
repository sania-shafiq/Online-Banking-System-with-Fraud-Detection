
<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];

$message = '';
$success = false;

// Process loan application
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['loan_submit'])) {
    $loan_type = $conn->real_escape_string($_POST['loan_type']);
    $amount = floatval($_POST['amount']);
    $purpose = $conn->real_escape_string($_POST['purpose']);
    $duration = intval($_POST['duration']);
    
    // Validation
    if($amount <= 0) {
        $message = "Please enter a valid loan amount!";
    } elseif($amount > 50000) {
        $message = "Maximum loan amount is $50,000!";
    } elseif($duration < 6 || $duration > 60) {
        $message = "Loan duration must be between 6-60 months!";
    } else {
        // Calculate interest based on loan type
        $interest_rates = [
            'personal' => 12.5,
            'home' => 8.5,
            'auto' => 9.5,
            'education' => 7.5,
            'business' => 10.5
        ];
        
        $interest_rate = $interest_rates[$loan_type] ?? 10.0;
        $monthly_interest = $interest_rate / 12 / 100;
        
        // Calculate monthly payment using EMI formula
        $emi = ($amount * $monthly_interest * pow(1 + $monthly_interest, $duration)) / 
               (pow(1 + $monthly_interest, $duration) - 1);
        
        // Insert loan application (using only existing columns)
$sql = "INSERT INTO loans (account_id, loan_type, amount, purpose, status) 
        VALUES (?, ?, ?, ?, 'Pending')";
$stmt = $conn->prepare($sql);
$stmt->bind_param("isds", $account_id, $loan_type, $amount, $purpose);
        
        if($stmt->execute()) {
            $message = "Loan application for $" . number_format($amount, 2) . " submitted successfully!";
            $success = true;
        } else {
            $message = "Error applying for loan. Please try again.";
        }
    }
}

// Get user's existing loans
$sql = "SELECT * FROM loans WHERE account_id = ? ORDER BY applied_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $account_id);
$stmt->execute();
$existing_loans = $stmt->get_result();

// Calculate total approved loan amount
$total_loan = getTotalLoan($conn, $account_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Apply for Loan</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Message Box */
        .message-box {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Loan Container */
        .loan-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Loan Status Card */
        .status-card {
            background: linear-gradient(135deg, #6f42c1, #8e44ad);
            color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(111, 66, 193, 0.2);
            height: fit-content;
        }
        
        .status-label {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .status-amount {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .account-number {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-top: 20px;
        }
        
        /* Existing Loans */
        .existing-loans {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .loans-title {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .loan-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .loan-item:last-child {
            border-bottom: none;
        }
        
        .loan-type {
            font-weight: 600;
        }
        
        .loan-status {
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 600;
        }
        
        .status-pending {
            background-color: rgba(255, 193, 7, 0.2);
            color: #ffc107;
        }
        
        .status-approved {
            background-color: rgba(40, 167, 69, 0.2);
            color: #28a745;
        }
        
        .status-rejected {
            background-color: rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
        
        /* Loan Form */
        .loan-form {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #6f42c1;
            outline: none;
        }
        
        .amount-input {
            position: relative;
        }
        
        .amount-input span {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            font-weight: 600;
            color: #666;
        }
        
        .amount-input input {
            padding-left: 40px;
        }
        
        /* Loan Types */
        .loan-types {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 10px;
        }
        
        .loan-type-option {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .loan-type-option:hover {
            border-color: #6f42c1;
            background-color: #f8f9fa;
        }
        
        .loan-type-option input[type="radio"] {
            width: auto;
        }
        
        .loan-icon {
            font-size: 1.5rem;
            color: #6f42c1;
        }
        
        .loan-type-info h4 {
            margin-bottom: 5px;
        }
        
        .loan-type-info p {
            font-size: 0.9rem;
            color: #666;
        }
        
        /* Form Actions */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            flex: 1;
        }
        
        .btn-primary {
            background-color: #6f42c1;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #5a32a3;
        }
        
        .btn-secondary {
            background-color: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-secondary:hover {
            background-color: #e9ecef;
        }
        
        /* Quick Amounts */
        .quick-amounts {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .quick-amount {
            padding: 8px 15px;
            background-color: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .quick-amount:hover {
            background-color: #e9ecef;
            border-color: #6f42c1;
        }
        
        /* EMI Calculator */
        .emi-calculator {
            background-color: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            display: none;
        }
        
        .emi-calculator.show {
            display: block;
            animation: slideDown 0.3s;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .emi-title {
            font-weight: 600;
            margin-bottom: 15px;
            color: #6f42c1;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .emi-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .emi-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .emi-item:last-child {
            border-bottom: none;
            font-weight: 600;
            color: #6f42c1;
        }
        
        /* Info Box */
        .info-box {
            background-color: #f8f9fa;
            border-left: 4px solid #6f42c1;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
        }
        
        .info-box h4 {
            color: #6f42c1;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-box ul {
            padding-left: 20px;
            color: #666;
        }
        
        .info-box li {
            margin-bottom: 8px;
        }
        
        /* Eligibility Notice */
        .eligibility-notice {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .eligibility-notice i {
            color: #ffc107;
            font-size: 1.2rem;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .loan-container {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .loan-types {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
            
            .emi-details {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link active">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Apply for Loan</h2>
                <p>Account: <?php echo $account_number; ?> | User: <?php echo htmlspecialchars($full_name); ?></p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Message Box -->
        <?php if($message): ?>
        <div class="message-box <?php echo $success ? 'success' : 'error'; ?>">
            <i class="fas <?php echo $success ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
            <?php if($success): ?>
            <script>
                setTimeout(() => {
                    window.location.href = 'loan.php';
                }, 2000);
            </script>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="loan-container">
            <!-- Loan Status Card -->
            <div class="status-card">
                <div class="status-label">LOAN ELIGIBILITY</div>
                <div class="status-amount">$50,000</div>
                
                <div class="status-label">CURRENT LOANS</div>
                <div class="status-amount" style="font-size: 2rem;">$<?php echo number_format($total_loan, 2); ?></div>
                
                <div class="account-number">
                    Credit Score: Excellent
                </div>
                
                <!-- Existing Loans -->
                <div class="existing-loans">
                    <div class="loans-title">Your Loan Applications</div>
                    <?php if($existing_loans->num_rows > 0): ?>
                        <?php while($loan = $existing_loans->fetch_assoc()): ?>
                        <div class="loan-item">
                            <div>
                                <div class="loan-type"><?php echo ucfirst($loan['loan_type']); ?> Loan</div>
                                <div style="font-size: 0.9rem; opacity: 0.8;">$<?php echo number_format($loan['amount'], 2); ?></div>
                            </div>
                            <div class="loan-status status-<?php echo strtolower($loan['status']); ?>">
                                <?php echo $loan['status']; ?>
                            </div>
                        </div>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <div class="loan-item">
                            <div>No loan applications</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Loan Form -->
            <div class="loan-form">
                <form method="POST" action="" id="loanForm">
                    <div class="form-group">
                        <label>Loan Type</label>
                        <div class="loan-types">
                            <label class="loan-type-option">
                                <input type="radio" name="loan_type" value="personal" required>
                                <div class="loan-icon">
                                    <i class="fas fa-user"></i>
                                </div>
                                <div class="loan-type-info">
                                    <h4>Personal</h4>
                                    <p>12.5% interest</p>
                                </div>
                            </label>
                            
                            <label class="loan-type-option">
                                <input type="radio" name="loan_type" value="home">
                                <div class="loan-icon">
                                    <i class="fas fa-home"></i>
                                </div>
                                <div class="loan-type-info">
                                    <h4>Home</h4>
                                    <p>8.5% interest</p>
                                </div>
                            </label>
                            
                            <label class="loan-type-option">
                                <input type="radio" name="loan_type" value="auto">
                                <div class="loan-icon">
                                    <i class="fas fa-car"></i>
                                </div>
                                <div class="loan-type-info">
                                    <h4>Auto</h4>
                                    <p>9.5% interest</p>
                                </div>
                            </label>
                            
                            <label class="loan-type-option">
                                <input type="radio" name="loan_type" value="education">
                                <div class="loan-icon">
                                    <i class="fas fa-graduation-cap"></i>
                                </div>
                                <div class="loan-type-info">
                                    <h4>Education</h4>
                                    <p>7.5% interest</p>
                                </div>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="amount">Loan Amount</label>
                        <div class="amount-input">
                            <span>$</span>
                            <input type="number" name="amount" id="loanAmount" 
                                   placeholder="Enter loan amount" 
                                   min="1000" max="50000" 
                                   step="100" required
                                   value="<?php echo isset($_POST['amount']) ? $_POST['amount'] : ''; ?>">
                        </div>
                        
                        <div class="quick-amounts">
                            <div class="quick-amount" onclick="setLoanAmount(5000)">$5,000</div>
                            <div class="quick-amount" onclick="setLoanAmount(10000)">$10,000</div>
                            <div class="quick-amount" onclick="setLoanAmount(25000)">$25,000</div>
                            <div class="quick-amount" onclick="setLoanAmount(50000)">$50,000</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="duration">Loan Duration (Months)</label>
                        <select name="duration" id="loanDuration" required>
                            <option value="">Select duration</option>
                            <option value="6">6 months</option>
                            <option value="12">12 months (1 year)</option>
                            <option value="24">24 months (2 years)</option>
                            <option value="36">36 months (3 years)</option>
                            <option value="48">48 months (4 years)</option>
                            <option value="60">60 months (5 years)</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="purpose">Purpose of Loan</label>
                        <textarea name="purpose" id="purpose" rows="3" 
                                  placeholder="Briefly describe why you need this loan"><?php echo isset($_POST['purpose']) ? $_POST['purpose'] : ''; ?></textarea>
                    </div>
                    
                    <!-- EMI Calculator -->
                    <div id="emiCalculator" class="emi-calculator">
                        <div class="emi-title">
                            <i class="fas fa-calculator"></i>
                            EMI Calculation
                        </div>
                        <div class="emi-details">
                            <div class="emi-item">
                                <span>Loan Amount:</span>
                                <span id="emiAmount">$0</span>
                            </div>
                            <div class="emi-item">
                                <span>Interest Rate:</span>
                                <span id="emiInterest">0%</span>
                            </div>
                            <div class="emi-item">
                                <span>Duration:</span>
                                <span id="emiDuration">0 months</span>
                            </div>
                            <div class="emi-item">
                                <span>Monthly EMI:</span>
                                <span id="emiMonthly">$0</span>
                            </div>
                            <div class="emi-item">
                                <span>Total Payable:</span>
                                <span id="emiTotal">$0</span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Eligibility Notice -->
                    <div class="eligibility-notice">
                        <i class="fas fa-info-circle"></i>
                        <div>
                            <strong>Eligibility:</strong> Minimum salary $2,000/month
                            <br>
                            <small>Processing time: 3-5 business days</small>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="loan_submit" class="btn btn-primary">
                            <i class="fas fa-paper-plane"></i> Submit Application
                        </button>
                        <a href="dashboard.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
                
                <!-- Info Box -->
                <div class="info-box">
                    <h4><i class="fas fa-info-circle"></i> Loan Information</h4>
                    <ul>
                        <li>Minimum loan amount: $1,000</li>
                        <li>Maximum loan amount: $50,000</li>
                        <li>Processing fee: 1% of loan amount</li>
                        <li>No prepayment penalty</li>
                        <li>Documents required: ID proof, Income proof</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Set quick amount
        function setLoanAmount(amount) {
            document.getElementById('loanAmount').value = amount;
            calculateEMI();
        }
        
        // Calculate EMI
        function calculateEMI() {
            const amount = parseFloat(document.getElementById('loanAmount').value) || 0;
            const duration = parseInt(document.getElementById('loanDuration').value) || 0;
            const loanType = document.querySelector('input[name="loan_type"]:checked')?.value;
            
            // Interest rates
            const interestRates = {
                'personal': 12.5,
                'home': 8.5,
                'auto': 9.5,
                'education': 7.5,
                'business': 10.5
            };
            
            const rate = loanType ? interestRates[loanType] : 10;
            const monthlyRate = rate / 12 / 100;
            
            if(amount > 0 && duration > 0 && monthlyRate > 0) {
                // EMI calculation formula
                const emi = (amount * monthlyRate * Math.pow(1 + monthlyRate, duration)) / 
                           (Math.pow(1 + monthlyRate, duration) - 1);
                const total = emi * duration;
                
                // Update display
                document.getElementById('emiAmount').textContent = '$' + amount.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
                document.getElementById('emiInterest').textContent = rate.toFixed(1) + '%';
                document.getElementById('emiDuration').textContent = duration + ' months';
                document.getElementById('emiMonthly').textContent = '$' + emi.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
                document.getElementById('emiTotal').textContent = '$' + total.toLocaleString('en-US', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                });
                
                // Show calculator
                document.getElementById('emiCalculator').classList.add('show');
            } else {
                document.getElementById('emiCalculator').classList.remove('show');
            }
        }
        
        // Event listeners for EMI calculation
        document.getElementById('loanAmount').addEventListener('input', calculateEMI);
        document.getElementById('loanDuration').addEventListener('change', calculateEMI);
        document.querySelectorAll('input[name="loan_type"]').forEach(radio => {
            radio.addEventListener('change', calculateEMI);
        });
        
        // Auto-select loan type if previously selected
        <?php if(isset($_POST['loan_type'])): ?>
        document.querySelectorAll('input[name="loan_type"]').forEach(radio => {
            if(radio.value === "<?php echo $_POST['loan_type']; ?>") {
                radio.checked = true;
                radio.parentElement.style.borderColor = '#6f42c1';
                radio.parentElement.style.backgroundColor = '#f8f9fa';
            }
        });
        <?php endif; ?>
        
        <?php if(isset($_POST['duration'])): ?>
        document.getElementById('loanDuration').value = "<?php echo $_POST['duration']; ?>";
        <?php endif; ?>
        
        // Highlight selected loan type
        document.querySelectorAll('.loan-type-option input').forEach(radio => {
            radio.addEventListener('change', function() {
                document.querySelectorAll('.loan-type-option').forEach(option => {
                    option.style.borderColor = '#e0e0e0';
                    option.style.backgroundColor = 'white';
                });
                
                if(this.checked) {
                    this.parentElement.style.borderColor = '#6f42c1';
                    this.parentElement.style.backgroundColor = '#f8f9fa';
                }
            });
        });
        
        // Form validation
        document.getElementById('loanForm').addEventListener('submit', function(e) {
            const amount = parseFloat(document.getElementById('loanAmount').value);
            const duration = parseInt(document.getElementById('loanDuration').value);
            const loanType = document.querySelector('input[name="loan_type"]:checked');
            
            if(!loanType) {
                alert('Please select a loan type!');
                e.preventDefault();
                return;
            }
            
            if(amount < 1000) {
                alert('Minimum loan amount is $1,000');
                e.preventDefault();
            }
            if(amount > 50000) {
                alert('Maximum loan amount is $50,000');
                e.preventDefault();
            }
            if(duration < 6 || duration > 60) {
                alert('Loan duration must be between 6-60 months');
                e.preventDefault();
            }
            
            // Confirm application
            if(!confirm('Are you sure you want to submit this loan application?')) {
                e.preventDefault();
            }
        });
        
        // Auto-calculate EMI on page load if values exist
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(calculateEMI, 100);
        });
    </script>
</body>
</html>
