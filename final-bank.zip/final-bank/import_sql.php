<?php
// Simple importer for local development when mysql client isn't available.
ini_set('display_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$user = 'root';
$pass = '';
$file = __DIR__ . DIRECTORY_SEPARATOR . 'database.sql';

if(!file_exists($file)){
    echo "SQL file not found: $file\n";
    exit(2);
}

$conn = new mysqli($host, $user, $pass);
if($conn->connect_error){
    echo "Connection error: " . $conn->connect_error . "\n";
    exit(3);
}

// Support a --force flag to DROP the database before importing
$force = false;
if (isset($argv) && is_array($argv)) {
    foreach ($argv as $arg) {
        if ($arg === '--force' || $arg === '-f') {
            $force = true;
            break;
        }
    }
}

if ($force) {
    echo "--force detected: dropping existing database 'banking_db' (if any)\n";
    if (!$conn->query("DROP DATABASE IF EXISTS banking_db")) {
        echo "Failed to drop database: " . $conn->error . "\n";
        // continue; we'll attempt import anyway
    } else {
        echo "Dropped existing database (if present).\n";
    }
}

$sql = file_get_contents($file);
if($sql === false){
    echo "Failed to read SQL file.\n";
    exit(4);
}

try {
    if($conn->multi_query($sql)){
        do {
            if ($result = $conn->store_result()) {
                $result->free();
            }
        } while ($conn->more_results() && $conn->next_result());

        if ($conn->errno) {
            echo "Import completed with errors: " . $conn->error . "\n";
            exit(5);
        }

        echo "Import completed successfully.\n";
        exit(0);
    } else {
        echo "Import failed: " . $conn->error . "\n";
        exit(6);
    }
} catch (mysqli_sql_exception $e) {
    echo "Import failed with exception: " . $e->getMessage() . "\n";
    exit(7);
}
