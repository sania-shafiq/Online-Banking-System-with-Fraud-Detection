
<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];
$account_type = $account['account_type'];
$status = $account['status'];

// Get user details
$sql = "SELECT * FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user_result = $stmt->get_result();
$user_details = $user_result->fetch_assoc();

// Get total transactions count
$sql = "SELECT COUNT(*) as total FROM transactions WHERE account_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $account_id);
$stmt->execute();
$trans_result = $stmt->get_result();
$trans_data = $trans_result->fetch_assoc();
$total_transactions = $trans_data['total'];

// Get total loan amount
$total_loan = getTotalLoan($conn, $account_id);

// Calculate account age
$account_age = date_diff(
    new DateTime($account['created_at']), 
    new DateTime()
)->format('%y years, %m months');

// Get last transaction
$sql = "SELECT * FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $account_id);
$stmt->execute();
$last_trans_result = $stmt->get_result();
$last_transaction = $last_trans_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Account Details</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Account Overview */
        .account-overview {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 30px;
            margin-bottom: 30px;
        }
        
        /* Account Card */
        .account-card {
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(26, 58, 143, 0.2);
            position: relative;
            overflow: hidden;
        }
        
        .account-card::before {
            content: '';
            position: absolute;
            top: -50px;
            right: -50px;
            width: 200px;
            height: 200px;
            background: rgba(255, 255, 255, 0.1);
            border-radius: 50%;
        }
        
        .account-card-content {
            position: relative;
            z-index: 1;
        }
        
        .account-name {
            font-size: 1.5rem;
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .account-number {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 25px;
        }
        
        .account-balance {
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 25px;
        }
        
        .account-details {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 25px;
        }
        
        .detail-item {
            display: flex;
            flex-direction: column;
        }
        
        .detail-label {
            font-size: 0.9rem;
            opacity: 0.8;
            margin-bottom: 5px;
        }
        
        .detail-value {
            font-size: 1.2rem;
            font-weight: 600;
        }
        
        /* Quick Actions Card */
        .quick-actions-card {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .card-title {
            font-size: 1.3rem;
            font-weight: 600;
            margin-bottom: 25px;
            color: #1a3a8f;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .action-buttons {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        
        .action-btn {
            display: flex;
            align-items: center;
            padding: 15px 20px;
            background-color: #f8f9fa;
            border-radius: 10px;
            text-decoration: none;
            color: #333;
            transition: all 0.3s;
            border: none;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 500;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            background-color: white;
        }
        
        .action-btn i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .deposit-btn i {
            color: #28a745;
        }
        
        .withdraw-btn i {
            color: #dc3545;
        }
        
        .transfer-btn i {
            color: #1a3a8f;
        }
        
        .statement-btn i {
            color: #6f42c1;
        }
        
        /* Account Details Grid */
        .account-details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }
        
        .details-card {
            background-color: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .details-header {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .details-header i {
            font-size: 1.5rem;
            color: #1a3a8f;
        }
        
        .details-header h3 {
            font-size: 1.2rem;
            font-weight: 600;
            color: #1a3a8f;
        }
        
        .details-list {
            list-style: none;
        }
        
        .details-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .details-item:last-child {
            border-bottom: none;
        }
        
        .item-label {
            color: #666;
            font-weight: 500;
        }
        
        .item-value {
            font-weight: 600;
            text-align: right;
        }
        
        .status-active {
            color: #28a745;
            background-color: rgba(40, 167, 69, 0.1);
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        .status-inactive {
            color: #dc3545;
            background-color: rgba(220, 53, 69, 0.1);
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.9rem;
        }
        
        /* Recent Activity */
        .recent-activity {
            background-color: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            margin-bottom: 30px;
        }
        
        .activity-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .view-all {
            color: #1a3a8f;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.9rem;
        }
        
        .view-all:hover {
            text-decoration: underline;
        }
        
        .activity-list {
            list-style: none;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            border-bottom: 1px solid #f0f0f0;
            transition: background-color 0.3s;
        }
        
        .activity-item:hover {
            background-color: #f8f9fa;
            border-radius: 8px;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
        }
        
        .activity-deposit {
            background-color: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }
        
        .activity-withdrawal {
            background-color: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
        
        .activity-transfer {
            background-color: rgba(26, 58, 143, 0.1);
            color: #1a3a8f;
        }
        
        .activity-content {
            flex: 1;
        }
        
        .activity-title {
            font-weight: 600;
            margin-bottom: 5px;
        }
        
        .activity-description {
            font-size: 0.9rem;
            color: #666;
        }
        
        .activity-amount {
            font-weight: 700;
            font-size: 1.1rem;
        }
        
        .amount-positive {
            color: #28a745;
        }
        
        .amount-negative {
            color: #dc3545;
        }
        
        /* Account Stats */
        .account-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background-color: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
            text-align: center;
        }
        
        .stat-icon {
            font-size: 2rem;
            margin-bottom: 15px;
            color: #1a3a8f;
        }
        
        .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .stat-label {
            font-size: 0.9rem;
            color: #666;
        }
        
        /* No Activity */
        .no-activity {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }
        
        .no-activity i {
            font-size: 2.5rem;
            margin-bottom: 15px;
            display: block;
            opacity: 0.5;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .account-overview {
                grid-template-columns: 1fr;
            }
            
            .account-balance {
                font-size: 2.2rem;
            }
        }
        
        @media (max-width: 768px) {
            .account-details {
                grid-template-columns: 1fr;
            }
            
            .account-details-grid {
                grid-template-columns: 1fr;
            }
            
            .account-stats {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
        }
        
        @media (max-width: 480px) {
            .account-stats {
                grid-template-columns: 1fr;
            }
            
            .activity-item {
                flex-direction: column;
                text-align: center;
                gap: 10px;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link active">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transactions.php" class="nav-link">
                    <i class="fas fa-history"></i>
                    <span>Transactions</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Account Details</h2>
                <p>Complete overview of your banking account</p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Account Holder</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Account Overview -->
        <div class="account-overview">
            <!-- Account Card -->
            <div class="account-card">
                <div class="account-card-content">
                    <div class="account-name"><?php echo htmlspecialchars($full_name); ?></div>
                    <div class="account-number">Account: <?php echo $account_number; ?></div>
                    
                    <div class="account-balance">$<?php echo number_format($current_balance, 2); ?></div>
                    
                    <div class="account-details">
                        <div class="detail-item">
                            <div class="detail-label">Account Type</div>
                            <div class="detail-value"><?php echo $account_type; ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Status</div>
                            <div class="detail-value"><?php echo $status; ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Member Since</div>
                            <div class="detail-value"><?php echo date('M Y', strtotime($account['created_at'])); ?></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Account Age</div>
                            <div class="detail-value"><?php echo $account_age; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="quick-actions-card">
                <h3 class="card-title">
                    <i class="fas fa-bolt"></i>
                    Quick Actions
                </h3>
                
                <div class="action-buttons">
                    <a href="deposit.php" class="action-btn deposit-btn">
                        <i class="fas fa-money-check-alt"></i>
                        <span>Deposit Money</span>
                    </a>
                    
                    <a href="withdraw.php" class="action-btn withdraw-btn">
                        <i class="fas fa-money-bill-wave"></i>
                        <span>Withdraw Money</span>
                    </a>
                    
                    <a href="transfer.php" class="action-btn transfer-btn">
                        <i class="fas fa-exchange-alt"></i>
                        <span>Transfer Money</span>
                    </a>
                    
                    <a href="transactions.php" class="action-btn statement-btn">
                        <i class="fas fa-file-invoice-dollar"></i>
                        <span>View Statement</span>
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Account Stats -->
        <div class="account-stats">
            <div class="stat-card">
                <i class="fas fa-exchange-alt stat-icon"></i>
                <div class="stat-value"><?php echo $total_transactions; ?></div>
                <div class="stat-label">Total Transactions</div>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-hand-holding-usd stat-icon"></i>
                <div class="stat-value">$<?php echo number_format($total_loan, 2); ?></div>
                <div class="stat-label">Active Loans</div>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-calendar-check stat-icon"></i>
                <div class="stat-value"><?php echo $account_age; ?></div>
                <div class="stat-label">Account Age</div>
            </div>
            
            <div class="stat-card">
                <i class="fas fa-star stat-icon"></i>
                <div class="stat-value">Premium</div>
                <div class="stat-label">Membership Level</div>
            </div>
        </div>
        
        <!-- Account Details Grid -->
        <div class="account-details-grid">
            <!-- Personal Details -->
            <div class="details-card">
                <div class="details-header">
                    <i class="fas fa-user-circle"></i>
                    <h3>Personal Details</h3>
                </div>
                
                <ul class="details-list">
                    <li class="details-item">
                        <span class="item-label">Full Name</span>
                        <span class="item-value"><?php echo htmlspecialchars($full_name); ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Email Address</span>
                        <span class="item-value"><?php echo htmlspecialchars($user_details['email']); ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Phone Number</span>
                        <span class="item-value"><?php echo htmlspecialchars($user_details['phone'] ?? 'Not provided'); ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Address</span>
                        <span class="item-value"><?php echo htmlspecialchars($user_details['address'] ?? 'Not provided'); ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Member Since</span>
                        <span class="item-value"><?php echo date('F j, Y', strtotime($user_details['created_at'])); ?></span>
                    </li>
                </ul>
            </div>
            
            <!-- Account Information -->
            <div class="details-card">
                <div class="details-header">
                    <i class="fas fa-university"></i>
                    <h3>Account Information</h3>
                </div>
                
                <ul class="details-list">
                    <li class="details-item">
                        <span class="item-label">Account Number</span>
                        <span class="item-value"><?php echo $account_number; ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Account Type</span>
                        <span class="item-value"><?php echo $account_type; ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Current Balance</span>
                        <span class="item-value">$<?php echo number_format($current_balance, 2); ?></span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Account Status</span>
                        <span class="item-value">
                            <span class="<?php echo $status == 'Active' ? 'status-active' : 'status-inactive'; ?>">
                                <?php echo $status; ?>
                            </span>
                        </span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Account Created</span>
                        <span class="item-value"><?php echo date('F j, Y', strtotime($account['created_at'])); ?></span>
                    </li>
                </ul>
            </div>
            
            <!-- Banking Services -->
            <div class="details-card">
                <div class="details-header">
                    <i class="fas fa-credit-card"></i>
                    <h3>Banking Services</h3>
                </div>
                
                <ul class="details-list">
                    <li class="details-item">
                        <span class="item-label">Online Banking</span>
                        <span class="item-value status-active">Enabled</span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Mobile Banking</span>
                        <span class="item-value status-active">Enabled</span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">ATM Card</span>
                        <span class="item-value">Active (**** 4567)</span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Cheque Book</span>
                        <span class="item-value">Available</span>
                    </li>
                    <li class="details-item">
                        <span class="item-label">Credit Limit</span>
                        <span class="item-value">$15,000.00</span>
                    </li>
                </ul>
            </div>
        </div>
        
        <!-- Recent Activity -->
        <div class="recent-activity">
            <div class="activity-header">
                <h3 class="card-title">
                    <i class="fas fa-history"></i>
                    Recent Activity
                </h3>
                <a href="transactions.php" class="view-all">View All Activity →</a>
            </div>
            
            <?php 
            // Get recent transactions (5 most recent)
            $sql = "SELECT * FROM transactions WHERE account_id = ? ORDER BY created_at DESC LIMIT 5";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $account_id);
            $stmt->execute();
            $recent_activities = $stmt->get_result();
            ?>
            
            <?php if($recent_activities->num_rows > 0): ?>
                <ul class="activity-list">
                    <?php while($activity = $recent_activities->fetch_assoc()): ?>
                    <li class="activity-item">
                        <div class="activity-icon activity-<?php echo strtolower($activity['type']); ?>">
                            <i class="fas <?php 
                                if($activity['type'] == 'Deposit') echo 'fa-arrow-down';
                                elseif($activity['type'] == 'Withdrawal') echo 'fa-arrow-up';
                                else echo 'fa-exchange-alt';
                            ?>"></i>
                        </div>
                        <div class="activity-content">
                            <div class="activity-title"><?php echo htmlspecialchars($activity['type']); ?></div>
                            <div class="activity-description"><?php echo htmlspecialchars($activity['description']); ?></div>
                        </div>
                        <div class="activity-amount <?php echo $activity['type'] == 'Deposit' ? 'amount-positive' : 'amount-negative'; ?>">
                            <?php echo ($activity['type'] == 'Deposit' ? '+' : '-') . '$' . number_format($activity['amount'], 2); ?>
                        </div>
                    </li>
                    <?php endwhile; ?>
                </ul>
            <?php else: ?>
                <div class="no-activity">
                    <i class="fas fa-history"></i>
                    <h3>No recent activity</h3>
                    <p>Your transaction history will appear here</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        // Print account details
        function printAccountDetails() {
            window.print();
        }
        
        // Add print button dynamically
        document.addEventListener('DOMContentLoaded', function() {
            const header = document.querySelector('.top-bar .welcome');
            if(header) {
                const printBtn = document.createElement('button');
                printBtn.className = 'action-btn';
                printBtn.innerHTML = '<i class="fas fa-print"></i> Print Details';
                printBtn.style.position = 'absolute';
                printBtn.style.right = '20px';
                printBtn.style.top = '20px';
                printBtn.style.backgroundColor = '#f8f9fa';
                printBtn.style.border = '2px solid #e0e0e0';
                printBtn.onclick = printAccountDetails;
                header.parentElement.style.position = 'relative';
                header.parentElement.appendChild(printBtn);
            }
        });
        
        // Format numbers with commas
        function formatNumber(number) {
            return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        }
        
        // Update all numbers on page
        document.addEventListener('DOMContentLoaded', function() {
            document.querySelectorAll('.stat-value').forEach(function(element) {
                const text = element.textContent.trim();
                if(text.startsWith('$')) {
                    const number = parseFloat(text.replace(/[^0-9.-]+/g,""));
                    if(!isNaN(number)) {
                        element.textContent = '$' + formatNumber(number.toFixed(2));
                    }
                } else if(!isNaN(text)) {
                    element.textContent = formatNumber(text);
                }
            });
        });
    </script>
</body>
</html>
