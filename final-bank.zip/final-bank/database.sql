-- ============================================
-- BANKING SYSTEM DATABASE
-- Simple and Clean Structure
-- ============================================

CREATE DATABASE IF NOT EXISTS banking_db;
USE banking_db;

-- ============================================
-- 1. USERS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- 2. ACCOUNTS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS accounts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    account_number VARCHAR(20) UNIQUE NOT NULL,
    balance DECIMAL(12,2) DEFAULT 0.00,
    account_type VARCHAR(20) DEFAULT 'Savings',
    status VARCHAR(20) DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- 3. TRANSACTIONS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT NOT NULL,
    type VARCHAR(20) NOT NULL, -- Deposit, Withdrawal, Transfer
    amount DECIMAL(12,2) NOT NULL,
    description VARCHAR(255),
    balance_after DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

-- ============================================
-- 4. LOANS TABLE
-- ============================================
CREATE TABLE IF NOT EXISTS loans (
    id INT PRIMARY KEY AUTO_INCREMENT,
    account_id INT NOT NULL,
    loan_type VARCHAR(50) NOT NULL, -- Personal, Home, Auto, Education
    amount DECIMAL(12,2) NOT NULL,
    purpose TEXT,
    status VARCHAR(20) DEFAULT 'Pending', -- Pending, Approved, Rejected
    applied_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

-- ============================================
-- SAMPLE TEST DATA (Optional)
-- ============================================
-- Insert a test user (password: password)
INSERT INTO users (full_name, email, password, phone) VALUES 
('Test User', 'test@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '9876543210');

-- Insert account for test user
INSERT INTO accounts (user_id, account_number, balance) VALUES 
(1, 'ACC20240001', 5000.00);

-- Insert some sample transactions
INSERT INTO transactions (account_id, type, amount, description, balance_after) VALUES 
(1, 'Deposit', 5000.00, 'Initial Deposit', 5000.00),
(1, 'Withdrawal', 1000.00, 'ATM Withdrawal', 4000.00);

-- ============================================
-- INDEXES FOR BETTER PERFORMANCE
-- ============================================
CREATE INDEX idx_accounts_user ON accounts(user_id);
CREATE INDEX idx_transactions_account ON transactions(account_id);
CREATE INDEX idx_transactions_date ON transactions(created_at);
CREATE INDEX idx_loans_account ON loans(account_id);