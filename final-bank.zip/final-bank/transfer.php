<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];

$message = '';
$success = false;
$recipient_name = '';

// Process transfer
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['transfer_submit'])) {
    $to_account = $conn->real_escape_string($_POST['to_account']);
    $amount = floatval($_POST['amount']);
    $description = $conn->real_escape_string($_POST['description']);
    
    // Validation
    if($to_account == $account_number) {
        $message = "You cannot transfer to your own account!";
    } elseif($amount <= 0) {
        $message = "Please enter a valid amount!";
    } elseif($amount > $current_balance) {
        $message = "Insufficient balance! Available: $" . number_format($current_balance, 2);
    } elseif($amount > 100000) {
        $message = "Maximum transfer amount is $100,000 per transaction!";
    } else {
        // Check if recipient account exists
        $check_sql = "SELECT a.*, u.full_name 
                      FROM accounts a 
                      JOIN users u ON a.user_id = u.id 
                      WHERE a.account_number = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $to_account);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if($check_result->num_rows == 0) {
            $message = "Recipient account not found!";
        } else {
            $recipient = $check_result->fetch_assoc();
            $recipient_name = $recipient['full_name'];
            $to_account_id = $recipient['id'];
            
            // Use transfer function from db.php
            $result = transferMoney($conn, $account_id, $to_account, $amount, $description);
            
            if($result == "success") {
                $message = "Transfer of $" . number_format($amount, 2) . " to " . $recipient_name . " successful!";
                $success = true;
                $current_balance = getCurrentBalance($conn, $account_id); // Update balance
            } else {
                $message = $result;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Transfer Money</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Message Box */
        .message-box {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Transfer Container */
        .transfer-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Balance Card */
        .balance-card {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(40, 167, 69, 0.2);
            height: fit-content;
        }
        
        .balance-label {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .balance-amount {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .account-number {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-top: 20px;
        }
        
        /* Recent Transfers */
        .recent-transfers {
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid rgba(255, 255, 255, 0.2);
        }
        
        .recent-title {
            font-size: 1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .recent-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .recent-item:last-child {
            border-bottom: none;
        }
        
        /* Transfer Form */
        .transfer-form {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group textarea:focus {
            border-color: #28a745;
            outline: none;
        }
        
        .amount-input {
            position: relative;
        }
        
        .amount-input span {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            font-weight: 600;
            color: #666;
        }
        
        .amount-input input {
            padding-left: 40px;
        }
        
        /* Recipient Info */
        .recipient-info {
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
            display: none;
        }
        
        .recipient-info.show {
            display: block;
            animation: slideDown 0.3s;
        }
        
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .recipient-details {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .recipient-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, #6c757d, #495057);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        .recipient-text h4 {
            margin-bottom: 5px;
        }
        
        .recipient-text p {
            color: #666;
            font-size: 0.9rem;
        }
        
        /* Form Actions */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            flex: 1;
        }
        
        .btn-success {
            background-color: #28a745;
            color: white;
        }
        
        .btn-success:hover {
            background-color: #218838;
        }
        
        .btn-secondary {
            background-color: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-secondary:hover {
            background-color: #e9ecef;
        }
        
        /* Quick Amounts */
        .quick-amounts {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .quick-amount {
            padding: 8px 15px;
            background-color: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .quick-amount:hover {
            background-color: #e9ecef;
            border-color: #28a745;
        }
        
        /* Info Box */
        .info-box {
            background-color: #f8f9fa;
            border-left: 4px solid #28a745;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
        }
        
        .info-box h4 {
            color: #28a745;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-box ul {
            padding-left: 20px;
            color: #666;
        }
        
        .info-box li {
            margin-bottom: 8px;
        }
        
        /* Transfer Fee */
        .transfer-fee {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .transfer-fee i {
            color: #ffc107;
            font-size: 1.2rem;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .transfer-container {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .form-actions {
                flex-direction: column;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link active">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Transfer Money</h2>
                <p>Account: <?php echo $account_number; ?> | User: <?php echo htmlspecialchars($full_name); ?></p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Message Box -->
        <?php if($message): ?>
        <div class="message-box <?php echo $success ? 'success' : 'error'; ?>">
            <i class="fas <?php echo $success ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
            <?php if($success): ?>
            <script>
                setTimeout(() => {
                    window.location.href = 'dashboard.php';
                }, 2000);
            </script>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="transfer-container">
            <!-- Balance Card -->
            <div class="balance-card">
                <div class="balance-label">AVAILABLE BALANCE</div>
                <div class="balance-amount">$<?php echo number_format($current_balance, 2); ?></div>
                
                <div class="balance-label">FROM ACCOUNT</div>
                <div class="balance-amount" style="font-size: 1.5rem;"><?php echo $account_number; ?></div>
                
                <div class="account-number">
                    Account Holder: <?php echo htmlspecialchars($full_name); ?>
                </div>
                
                <!-- Recent Transfers -->
                <div class="recent-transfers">
                    <div class="recent-title">Recent Transfers</div>
                    <?php
                    // Get recent transfers
                    $sql = "SELECT * FROM transactions 
                            WHERE account_id = ? AND type = 'Transfer' 
                            ORDER BY created_at DESC LIMIT 3";
                    $stmt = $conn->prepare($sql);
                    $stmt->bind_param("i", $account_id);
                    $stmt->execute();
                    $recent = $stmt->get_result();
                    
                    if($recent->num_rows > 0):
                        while($transfer = $recent->fetch_assoc()):
                            // Extract account number from description
                            preg_match('/to (\w+) -/', $transfer['description'], $matches);
                            $to_acc = $matches[1] ?? 'Unknown';
                    ?>
                    <div class="recent-item">
                        <span>To: <?php echo substr($to_acc, 0, 4) . '****'; ?></span>
                        <span style="font-weight: 600;">$<?php echo number_format($transfer['amount'], 2); ?></span>
                    </div>
                    <?php endwhile; ?>
                    <?php else: ?>
                    <div class="recent-item">
                        <span>No recent transfers</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Transfer Form -->
            <div class="transfer-form">
                <form method="POST" action="" id="transferForm">
                    <div class="form-group">
                        <label for="to_account">Recipient Account Number</label>
                        <input type="text" name="to_account" id="to_account" 
                               placeholder="Enter recipient's account number" 
                               required
                               value="<?php echo isset($_POST['to_account']) ? $_POST['to_account'] : ''; ?>">
                        
                        <!-- Recipient Info -->
                        <div id="recipientInfo" class="recipient-info <?php echo $recipient_name ? 'show' : ''; ?>">
                            <?php if($recipient_name): ?>
                            <div class="recipient-details">
                                <div class="recipient-icon"><?php echo strtoupper(substr($recipient_name, 0, 2)); ?></div>
                                <div class="recipient-text">
                                    <h4><?php echo htmlspecialchars($recipient_name); ?></h4>
                                    <p>Account: <?php echo isset($_POST['to_account']) ? $_POST['to_account'] : ''; ?></p>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="amount">Transfer Amount</label>
                        <div class="amount-input">
                            <span>$</span>
                            <input type="number" name="amount" id="amount" 
                                   placeholder="Enter amount" 
                                   min="10" max="100000" 
                                   step="0.01" required
                                   value="<?php echo isset($_POST['amount']) ? $_POST['amount'] : ''; ?>">
                        </div>
                        
                        <div class="quick-amounts">
                            <div class="quick-amount" onclick="setAmount(100)">$100</div>
                            <div class="quick-amount" onclick="setAmount(500)">$500</div>
                            <div class="quick-amount" onclick="setAmount(1000)">$1,000</div>
                            <div class="quick-amount" onclick="setAmount(5000)">$5,000</div>
                            <div class="quick-amount" onclick="setAmount(10000)">$10,000</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Description (Optional)</label>
                        <textarea name="description" id="description" rows="3" 
                                  placeholder="e.g., Rent payment, Gift, etc."><?php echo isset($_POST['description']) ? $_POST['description'] : ''; ?></textarea>
                    </div>
                    
                    <!-- Transfer Fee Notice -->
                    <div class="transfer-fee">
                        <i class="fas fa-info-circle"></i>
                        <div>
                            <strong>Transfer Fee:</strong> $0 for premium members
                            <br>
                            <small>Instant transfer | Processed immediately</small>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="transfer_submit" class="btn btn-success">
                            <i class="fas fa-paper-plane"></i> Send Money
                        </button>
                        <a href="dashboard.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
                
                <!-- Info Box -->
                <div class="info-box">
                    <h4><i class="fas fa-info-circle"></i> Transfer Information</h4>
                    <ul>
                        <li>Minimum transfer amount: $10</li>
                        <li>Maximum transfer amount: $100,000 per day</li>
                        <li>Transfers are processed instantly</li>
                        <li>No fees for premium members</li>
                        <li>Verify account number before sending</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Set quick amount
        function setAmount(amount) {
            document.getElementById('amount').value = amount;
        }
        
        // Check recipient account as user types
        let checkTimeout;
        document.getElementById('to_account').addEventListener('input', function() {
            clearTimeout(checkTimeout);
            const account = this.value.trim();
            
            if(account.length >= 8) {
                checkTimeout = setTimeout(() => {
                    checkRecipientAccount(account);
                }, 500);
            } else {
                document.getElementById('recipientInfo').classList.remove('show');
            }
        });
        
        // Check balance before submission
        document.getElementById('amount').addEventListener('input', function() {
            const amount = parseFloat(this.value) || 0;
            const balance = <?php echo $current_balance; ?>;
            
            if(amount > balance) {
                this.style.borderColor = '#dc3545';
                this.style.backgroundColor = '#f8d7da';
            } else {
                this.style.borderColor = '#e0e0e0';
                this.style.backgroundColor = 'white';
            }
        });
        
        // Form validation
        document.getElementById('transferForm').addEventListener('submit', function(e) {
            const amount = parseFloat(document.getElementById('amount').value);
            const balance = <?php echo $current_balance; ?>;
            const toAccount = document.getElementById('to_account').value;
            const fromAccount = '<?php echo $account_number; ?>';
            
            if(toAccount === fromAccount) {
                alert('You cannot transfer to your own account!');
                e.preventDefault();
                return;
            }
            
            if(amount < 10) {
                alert('Minimum transfer amount is $10');
                e.preventDefault();
            }
            if(amount > 100000) {
                alert('Maximum transfer amount is $100,000 per day');
                e.preventDefault();
            }
            if(amount > balance) {
                alert('Insufficient balance! Available: $' + balance.toFixed(2));
                e.preventDefault();
            }
            
            // Confirm transfer
            if(!confirm('Are you sure you want to transfer $' + amount.toFixed(2) + '?')) {
                e.preventDefault();
            }
        });
        
        // Simulate checking recipient account (in real app, this would be AJAX)
        function checkRecipientAccount(account) {
            const recipientInfo = document.getElementById('recipientInfo');
            
            // For demo, show fake recipient info
            if(account.length >= 8 && account !== '<?php echo $account_number; ?>') {
                const fakeNames = ['John Smith', 'Emma Wilson', 'Robert Johnson', 'Sarah Davis'];
                const randomName = fakeNames[Math.floor(Math.random() * fakeNames.length)];
                
                recipientInfo.innerHTML = `
                    <div class="recipient-details">
                        <div class="recipient-icon">${randomName.charAt(0)}${randomName.split(' ')[1]?.charAt(0) || 'U'}</div>
                        <div class="recipient-text">
                            <h4>${randomName}</h4>
                            <p>Account: ${account}</p>
                            <small style="color: #28a745;">✓ Account verified</small>
                        </div>
                    </div>
                `;
                recipientInfo.classList.add('show');
            } else {
                recipientInfo.classList.remove('show');
            }
        }
    </script>
</body>
</html>