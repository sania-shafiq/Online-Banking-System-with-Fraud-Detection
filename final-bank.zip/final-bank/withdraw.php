<?php
session_start();
include 'db.php';
checkLogin();

$user_id = $_SESSION['user_id'];
$full_name = $_SESSION['full_name'];

// Get user account
$account = getUserAccount($conn, $user_id);
$account_id = $account['id'];
$account_number = $account['account_number'];
$current_balance = $account['balance'];

$message = '';
$success = false;

// Process withdrawal
if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['withdraw_submit'])) {
    $amount = floatval($_POST['amount']);
    $method = $conn->real_escape_string($_POST['method']);
    $description = $conn->real_escape_string($_POST['description']);
    
    // Validation
    if($amount <= 0) {
        $message = "Please enter a valid amount!";
    } elseif($amount > $current_balance) {
        $message = "Insufficient balance! Available: $" . number_format($current_balance, 2);
    } elseif($amount > 50000) {
        $message = "Maximum withdrawal amount is $50,000 per transaction!";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Update balance (subtract)
            updateBalance($conn, $account_id, $amount, 'Withdrawal');
            
            // Get new balance
            $new_balance = getCurrentBalance($conn, $account_id);
            
            // Record transaction
            $desc = "Withdrawal via " . $method . " - " . $description;
            $sql = "INSERT INTO transactions (account_id, type, amount, description, balance_after) 
                    VALUES (?, 'Withdrawal', ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("idsd", $account_id, $amount, $desc, $new_balance);
            $stmt->execute();
            
            $conn->commit();
            
            $message = "Withdrawal of $" . number_format($amount, 2) . " successful!";
            $success = true;
            $current_balance = $new_balance; // Update current balance
            
        } catch (Exception $e) {
            $conn->rollback();
            $message = "Error: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SecureBank | Withdraw Money</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }
        
        body {
            background-color: #f5f7fb;
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar */
        .sidebar {
            width: 250px;
            background: linear-gradient(to bottom, #1a3a8f, #2c5cc5);
            color: white;
            padding: 25px 0;
            position: fixed;
            height: 100vh;
            box-shadow: 3px 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            display: flex;
            align-items: center;
            padding: 0 25px;
            margin-bottom: 40px;
        }
        
        .logo i {
            font-size: 2.2rem;
            margin-right: 12px;
        }
        
        .logo h1 {
            font-size: 1.5rem;
            font-weight: 700;
        }
        
        .nav-menu {
            list-style: none;
            margin-top: 20px;
        }
        
        .nav-item {
            margin-bottom: 5px;
        }
        
        .nav-link {
            display: flex;
            align-items: center;
            padding: 15px 25px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-link:hover {
            background-color: rgba(255, 255, 255, 0.1);
            color: white;
            padding-left: 30px;
        }
        
        .nav-link.active {
            background-color: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid #6cbbff;
        }
        
        .nav-link i {
            font-size: 1.2rem;
            margin-right: 15px;
            width: 24px;
            text-align: center;
        }
        
        .logout {
            margin-top: 40px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            padding-top: 20px;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 25px;
        }
        
        /* Top Bar */
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .welcome h2 {
            font-size: 1.8rem;
            color: #1a3a8f;
        }
        
        .welcome p {
            color: #666;
            margin-top: 5px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .profile-pic {
            width: 45px;
            height: 45px;
            border-radius: 50%;
            background: linear-gradient(135deg, #1a3a8f, #2c5cc5);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            font-size: 1.2rem;
        }
        
        /* Message Box */
        .message-box {
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 10px;
            animation: fadeIn 0.5s;
        }
        
        .success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        /* Page Title */
        .page-title {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .page-title i {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        .page-title h1 {
            font-size: 2rem;
            color: #1a3a8f;
        }
        
        /* Withdraw Container */
        .withdraw-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            max-width: 1200px;
            margin: 0 auto;
        }
        
        /* Balance Card */
        .balance-card {
            background: linear-gradient(135deg, #dc3545, #c82333);
            color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 10px 20px rgba(220, 53, 69, 0.2);
            height: fit-content;
        }
        
        .balance-label {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-bottom: 10px;
        }
        
        .balance-amount {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 20px;
        }
        
        .account-number {
            font-size: 1.1rem;
            opacity: 0.9;
            margin-top: 20px;
        }
        
        /* Withdraw Form */
        .withdraw-form {
            background-color: white;
            border-radius: 15px;
            padding: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 1rem;
            transition: border-color 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            border-color: #dc3545;
            outline: none;
        }
        
        .amount-input {
            position: relative;
        }
        
        .amount-input span {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 1.2rem;
            font-weight: 600;
            color: #666;
        }
        
        .amount-input input {
            padding-left: 40px;
        }
        
        /* Withdrawal Methods */
        .withdraw-methods {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 10px;
        }
        
        .method-option {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .method-option:hover {
            border-color: #dc3545;
            background-color: #f8f9fa;
        }
        
        .method-option input[type="radio"] {
            width: auto;
        }
        
        .method-icon {
            font-size: 1.5rem;
            color: #dc3545;
        }
        
        .method-info h4 {
            margin-bottom: 5px;
        }
        
        .method-info p {
            font-size: 0.9rem;
            color: #666;
        }
        
        /* Form Actions */
        .form-actions {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }
        
        .btn {
            padding: 14px 30px;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            flex: 1;
        }
        
        .btn-danger {
            background-color: #dc3545;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .btn-secondary {
            background-color: #f8f9fa;
            color: #333;
            border: 2px solid #e0e0e0;
        }
        
        .btn-secondary:hover {
            background-color: #e9ecef;
        }
        
        /* Quick Amounts */
        .quick-amounts {
            display: flex;
            gap: 10px;
            margin-top: 10px;
            flex-wrap: wrap;
        }
        
        .quick-amount {
            padding: 8px 15px;
            background-color: #f8f9fa;
            border: 2px solid #e0e0e0;
            border-radius: 6px;
            cursor: pointer;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .quick-amount:hover {
            background-color: #e9ecef;
            border-color: #dc3545;
        }
        
        /* Info Box */
        .info-box {
            background-color: #f8f9fa;
            border-left: 4px solid #dc3545;
            padding: 20px;
            border-radius: 8px;
            margin-top: 30px;
        }
        
        .info-box h4 {
            color: #dc3545;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .info-box ul {
            padding-left: 20px;
            color: #666;
        }
        
        .info-box li {
            margin-bottom: 8px;
        }
        
        /* Daily Limit */
        .daily-limit {
            background-color: #fff3cd;
            border: 1px solid #ffeaa7;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .daily-limit i {
            color: #ffc107;
            font-size: 1.2rem;
        }
        
        /* Responsive */
        @media (max-width: 992px) {
            .sidebar {
                width: 80px;
                padding: 25px 0;
            }
            
            .logo h1, .nav-link span {
                display: none;
            }
            
            .logo {
                justify-content: center;
                padding: 0;
            }
            
            .logo i {
                margin-right: 0;
                font-size: 2rem;
            }
            
            .nav-link {
                justify-content: center;
                padding: 15px 0;
            }
            
            .nav-link i {
                margin-right: 0;
                font-size: 1.5rem;
            }
            
            .main-content {
                margin-left: 80px;
            }
            
            .withdraw-container {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 768px) {
            .withdraw-methods {
                grid-template-columns: 1fr;
            }
            
            .form-actions {
                flex-direction: column;
            }
            
            .top-bar {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                width: 100%;
                justify-content: space-between;
            }
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <i class="fas fa-university"></i>
            <h1>SecureBank</h1>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="dashboard.php" class="nav-link">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="account.php" class="nav-link">
                    <i class="fas fa-wallet"></i>
                    <span>Account</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="deposit.php" class="nav-link">
                    <i class="fas fa-money-check-alt"></i>
                    <span>Deposit</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="withdraw.php" class="nav-link active">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Withdraw</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="transfer.php" class="nav-link">
                    <i class="fas fa-exchange-alt"></i>
                    <span>Transfer</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="loan.php" class="nav-link">
                    <i class="fas fa-hand-holding-usd"></i>
                    <span>Loans</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="profile.php" class="nav-link">
                    <i class="fas fa-user"></i>
                    <span>Profile</span>
                </a>
            </li>
        </ul>
        
        <div class="logout">
            <a href="logout.php" class="nav-link">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="welcome">
                <h2>Withdraw Money</h2>
                <p>Account: <?php echo $account_number; ?> | User: <?php echo htmlspecialchars($full_name); ?></p>
            </div>
            
            <div class="user-info">
                <div class="user-profile">
                    <div class="profile-pic"><?php echo strtoupper(substr($full_name, 0, 2)); ?></div>
                    <div>
                        <div style="font-weight: 600;"><?php echo htmlspecialchars($full_name); ?></div>
                        <div style="font-size: 0.9rem; color: #666;">Premium Member</div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Message Box -->
        <?php if($message): ?>
        <div class="message-box <?php echo $success ? 'success' : 'error'; ?>">
            <i class="fas <?php echo $success ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
            <?php echo htmlspecialchars($message); ?>
            <?php if($success): ?>
            <script>
                setTimeout(() => {
                    window.location.href = 'dashboard.php';
                }, 2000);
            </script>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        
        <div class="withdraw-container">
            <!-- Balance Card -->
            <div class="balance-card">
                <div class="balance-label">AVAILABLE BALANCE</div>
                <div class="balance-amount">$<?php echo number_format($current_balance, 2); ?></div>
                
                <div class="balance-label">DAILY WITHDRAWAL LIMIT</div>
                <div class="balance-amount">$50,000</div>
                
                <div class="account-number">
                    Account: <?php echo $account_number; ?>
                </div>
            </div>
            
            <!-- Withdraw Form -->
            <div class="withdraw-form">
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="amount">Amount to Withdraw</label>
                        <div class="amount-input">
                            <span>$</span>
                            <input type="number" name="amount" id="amount" 
                                   placeholder="Enter amount" 
                                   min="100" max="50000" 
                                   step="0.01" required
                                   value="<?php echo isset($_POST['amount']) ? $_POST['amount'] : ''; ?>">
                        </div>
                        
                        <div class="quick-amounts">
                            <div class="quick-amount" onclick="setAmount(100)">$100</div>
                            <div class="quick-amount" onclick="setAmount(500)">$500</div>
                            <div class="quick-amount" onclick="setAmount(1000)">$1,000</div>
                            <div class="quick-amount" onclick="setAmount(5000)">$5,000</div>
                            <div class="quick-amount" onclick="setAmount(10000)">$10,000</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label>Withdrawal Method</label>
                        <div class="withdraw-methods">
                            <label class="method-option">
                                <input type="radio" name="method" value="ATM Withdrawal" required>
                                <div class="method-icon">
                                    <i class="fas fa-atm"></i>
                                </div>
                                <div class="method-info">
                                    <h4>ATM</h4>
                                    <p>Cash from ATM</p>
                                </div>
                            </label>
                            
                            <label class="method-option">
                                <input type="radio" name="method" value="Bank Branch">
                                <div class="method-icon">
                                    <i class="fas fa-university"></i>
                                </div>
                                <div class="method-info">
                                    <h4>Bank Branch</h4>
                                    <p>Visit branch</p>
                                </div>
                            </label>
                            
                            <label class="method-option">
                                <input type="radio" name="method" value="Cheque">
                                <div class="method-icon">
                                    <i class="fas fa-money-check"></i>
                                </div>
                                <div class="method-info">
                                    <h4>Cheque</h4>
                                    <p>Issue cheque</p>
                                </div>
                            </label>
                            
                            <label class="method-option">
                                <input type="radio" name="method" value="Online Transfer">
                                <div class="method-icon">
                                    <i class="fas fa-desktop"></i>
                                </div>
                                <div class="method-info">
                                    <h4>Online Transfer</h4>
                                    <p>To other account</p>
                                </div>
                            </label>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="description">Purpose (Optional)</label>
                        <textarea name="description" id="description" rows="3" 
                                  placeholder="e.g., For shopping, Bill payment, etc."><?php echo isset($_POST['description']) ? $_POST['description'] : ''; ?></textarea>
                    </div>
                    
                    <!-- Daily Limit Notice -->
                    <div class="daily-limit">
                        <i class="fas fa-exclamation-triangle"></i>
                        <div>
                            <strong>Daily Withdrawal Limit:</strong> $50,000
                            <br>
                            <small>Used today: $0.00 | Remaining: $50,000</small>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="withdraw_submit" class="btn btn-danger">
                            <i class="fas fa-check-circle"></i> Confirm Withdrawal
                        </button>
                        <a href="dashboard.php" class="btn btn-secondary">
                            <i class="fas fa-times"></i> Cancel
                        </a>
                    </div>
                </form>
                
                <!-- Info Box -->
                <div class="info-box">
                    <h4><i class="fas fa-info-circle"></i> Withdrawal Information</h4>
                    <ul>
                        <li>Minimum withdrawal amount: $100</li>
                        <li>Maximum withdrawal amount: $50,000 per day</li>
                        <li>ATM withdrawal fee: $0 for premium members</li>
                        <li>Cheque processing: 2-3 business days</li>
                        <li>Large withdrawals may require branch visit</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Set quick amount
        function setAmount(amount) {
            document.getElementById('amount').value = amount;
        }
        
        // Check balance before submission
        document.getElementById('amount').addEventListener('input', function() {
            const amount = parseFloat(this.value) || 0;
            const balance = <?php echo $current_balance; ?>;
            
            if(amount > balance) {
                this.style.borderColor = '#dc3545';
                this.style.backgroundColor = '#f8d7da';
            } else {
                this.style.borderColor = '#e0e0e0';
                this.style.backgroundColor = 'white';
            }
        });
        
        // Auto-select withdrawal method if previously selected
        <?php if(isset($_POST['method'])): ?>
        document.querySelectorAll('input[name="method"]').forEach(radio => {
            if(radio.value === "<?php echo $_POST['method']; ?>") {
                radio.checked = true;
                radio.parentElement.style.borderColor = '#dc3545';
                radio.parentElement.style.backgroundColor = '#f8f9fa';
            }
        });
        <?php endif; ?>
        
        // Highlight selected method
        document.querySelectorAll('.method-option input').forEach(radio => {
            radio.addEventListener('change', function() {
                document.querySelectorAll('.method-option').forEach(option => {
                    option.style.borderColor = '#e0e0e0';
                    option.style.backgroundColor = 'white';
                });
                
                if(this.checked) {
                    this.parentElement.style.borderColor = '#dc3545';
                    this.parentElement.style.backgroundColor = '#f8f9fa';
                }
            });
        });
        
        // Form validation
        document.querySelector('form').addEventListener('submit', function(e) {
            const amount = parseFloat(document.getElementById('amount').value);
            const balance = <?php echo $current_balance; ?>;
            
            if(amount < 100) {
                alert('Minimum withdrawal amount is $100');
                e.preventDefault();
            }
            if(amount > 50000) {
                alert('Maximum withdrawal amount is $50,000 per day');
                e.preventDefault();
            }
            if(amount > balance) {
                alert('Insufficient balance! Available: $' + balance.toFixed(2));
                e.preventDefault();
            }
        });
    </script>
</body>
</html>